/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLSpanElement | HTMLButtonElement | HTMLAnchorElement> {
    /**
     * Flag that indicates if item is selected.
     */
    'active'?: boolean;
    /**
     * @ignore
     */
    'data-index'?: number;
    /**
     * Flag that indicates if item is disabled or not.
     */
    'disabled'?: boolean;
    /**
     * Path for item to link to.
     */
    'href'?: string;
    'innerRef'?: React.Ref<any>;
    /**
     * Sets the role accessibility property of the item. Set the item's
     * container (<li />) role use the role="" prop instead of roleItem="".
     */
    'roleItem'?: string;
    /**
     * Path to icon spritemap from clay-css.
     */
    'spritemap'?: string;
    /**
     * Flag that indicates if there is an icon symbol on the left side.
     */
    'symbolLeft'?: string;
    /**
     * Flag that indicates if there is an icon symbol on the right side.
     */
    'symbolRight'?: string;
}
declare const Item: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLLIElement>>;
export default Item;
