/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { LRUCache } from './LRUCache';
declare type Options = {
    storageMaxSize?: number;
};
export declare class DataClient {
    cache: LRUCache<string, any>;
    currentPromises: Record<string, Promise<any> | Error>;
    cursors: Record<string, string | undefined>;
    constructor({ storageMaxSize }?: Options);
    read(key: string | null): any;
    remove(key: string | null): void;
    update(key: string | null, value: any): null | undefined;
    isFetching(key: string | null): Error | Promise<any> | undefined;
    getCursor(key: string | null): string | null | undefined;
    setCursor(key: string | null, value: string | undefined): null | undefined;
}
export {};
