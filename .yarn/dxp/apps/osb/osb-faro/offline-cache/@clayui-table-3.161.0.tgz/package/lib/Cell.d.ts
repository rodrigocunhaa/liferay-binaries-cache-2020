/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { TDelimiter } from './types';
declare type ColumnTextAlignmentType = 'center' | 'end' | 'start';
declare type TableCellBaseProps = React.ThHTMLAttributes<HTMLTableHeaderCellElement> & React.TdHTMLAttributes<HTMLTableDataCellElement>;
declare type TextCellAlignmentType = 'center' | 'left' | 'right';
export interface ICellProps extends TableCellBaseProps {
    /**
     * Aligns the text inside the Cell.
     */
    align?: TextCellAlignmentType;
    /**
     * Sometimes we are unable to remove specific table columns from the DOM
     * and need to hide it using CSS. This property can be added to the "new"
     * first or last cell to maintain table styles on the left and right side.
     */
    cellDelimiter?: TDelimiter;
    /**
     * Aligns horizontally contents inside the Cell.
     */
    columnTextAlignment?: ColumnTextAlignmentType;
    /**
     * Fills out the remaining space inside a Cell.
     */
    expanded?: boolean;
    /**
     * Defines the type of the Cell element, if true,
     * cell element will be a `<th>`, otherwise `<td>`.
     */
    headingCell?: boolean;
    /**
     * Applies a style of heading inside a child of table
     * header cell element.
     */
    headingTitle?: boolean;
    noWrap?: boolean;
    /**
     * Truncates the text inside a Cell. Requires `expanded`
     * property value set to true.
     */
    truncate?: boolean;
}
declare const ClayTableCell: React.ForwardRefExoticComponent<ICellProps & React.RefAttributes<HTMLTableDataCellElement | HTMLTableHeaderCellElement>>;
export default ClayTableCell;
