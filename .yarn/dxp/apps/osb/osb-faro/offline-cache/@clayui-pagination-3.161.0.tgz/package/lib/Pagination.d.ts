/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { Ellipsis } from './Ellipsis';
import { Item } from './Item';
export interface IProps extends React.HTMLAttributes<HTMLUListElement> {
    /**
     * The size of pagination element.
     * @deprecated since v3.146.0 with no replacement.
     */
    size?: 'lg' | 'sm';
}
export declare const Pagination: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLUListElement>> & {
    Ellipsis: typeof Ellipsis;
    Item: typeof Item;
};
