/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IContentRowProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
    /**
     * Provides the benefit of aligning content via flexbox without losing the behavior
     * of floated elements at the expense of extra markup.
     */
    float?: boolean | 'sm-down' | 'md-down' | 'end' | 'end-sm-down' | 'end-md-down';
    noGutters?: 'sm' | 'x' | 'y' | true;
    padded?: boolean;
    /**
     * Adds class for aligning items within the row.
     */
    verticalAlign?: 'center' | 'end';
}
declare const ContentRow: React.ForwardRefExoticComponent<IContentRowProps & React.RefAttributes<HTMLElement>>;
export interface IContentColProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
    expand?: boolean;
    /**
     * Provides the benefit of aligning content via flexbox without losing the behavior
     * of floated elements at the expense of extra markup.
     */
    float?: 'end';
    /**
     * Applies the `autofit-col-gutters` class
     */
    gutters?: boolean;
    /**
     * Applies the `autofit-col-shrink` class.
     */
    shrink?: boolean;
}
declare const ContentCol: React.ForwardRefExoticComponent<IContentColProps & React.RefAttributes<HTMLElement>>;
export interface IColSectionProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
}
declare const ContentSection: React.ForwardRefExoticComponent<IColSectionProps & React.RefAttributes<HTMLElement>>;
export { ContentCol, ContentRow, ContentSection };
