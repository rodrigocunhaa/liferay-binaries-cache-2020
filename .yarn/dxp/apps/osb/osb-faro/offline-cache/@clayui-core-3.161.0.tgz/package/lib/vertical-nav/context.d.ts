/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React, { ReactNode } from 'react';
import type { ChildrenFunction } from '../collection';
declare type VerticalNavContextProps = {
    activeKey?: React.Key | null;
    ariaCurrent?: 'page' | null;
    childrenRoot: React.MutableRefObject<React.ReactNode | ChildrenFunction<Object, null>>;
    close: (key: React.Key) => void;
    expandedKeys: Set<React.Key>;
    firstKey: React.Key;
    focusedElement?: HTMLElement | null;
    open: (key: React.Key) => void;
    spritemap?: string;
    toggle: (key: React.Key) => void;
};
declare function VerticalNavContextProvider({ activeKey, ariaCurrent, children, childrenRoot, close, expandedKeys, firstKey, focusedElement, open, spritemap, toggle, }: VerticalNavContextProps & {
    children: ReactNode;
}): React.JSX.Element;
declare function useVerticalNavContext(): VerticalNavContextProps & {
    setManualFocusedElement: React.Dispatch<React.SetStateAction<HTMLElement | null>>;
};
declare function useSetManualFocus(): (element: HTMLElement | null) => void;
export { VerticalNavContextProvider, useSetManualFocus, useVerticalNavContext };
