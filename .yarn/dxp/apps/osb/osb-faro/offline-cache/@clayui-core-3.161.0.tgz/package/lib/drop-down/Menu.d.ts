/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import type { ICollectionProps } from '../collection';
declare type Props<T> = {
    'UNSAFE_focusableElements'?: Array<string>;
    /**
     * Flag to indicate if menu is showing or not (controlled).
     */
    'active'?: boolean;
    'alwaysClose'?: boolean;
    /**
     * The `aria-label` attribute defines a string value that labels an interactive
     * element.
     */
    'aria-label'?: string;
    /**
     * The `aria-labelledby` attribute identifies the element (or elements) that
     * labels the element it is applied to.
     */
    'aria-labelledby'?: string;
    /**
     * Custom container component.
     */
    'as'?: 'div' | React.ForwardRefExoticComponent<any> | ((props: React.HTMLAttributes<HTMLDivElement>) => JSX.Element);
    /**
     * CSS clases to menu element.
     */
    'className'?: string;
    /**
     * The initial value of the active state (uncontrolled).
     */
    'defaultActive'?: boolean;
    /**
     * Flag to indicate that the component is disabled.
     */
    'disabled'?: boolean;
    /**
     * Callback for when the active state changes (controlled).
     */
    'onActiveChange'?: InternalDispatch<boolean>;
    /**
     * Defines the ARIA role of the menu.
     */
    'role'?: 'menu' | 'listbox';
    'style'?: React.CSSProperties;
    /**
     * Trigger menu.
     */
    'trigger': React.ReactElement & {
        ref?: (node: HTMLButtonElement | null) => void;
    };
} & Omit<Partial<ICollectionProps<T, unknown>>, 'virtualize'>;
declare type ForwardRef = {
    <T>(props: Props<T> & {
        ref?: React.Ref<HTMLDivElement>;
    }): JSX.Element;
    displayName: string;
};
/**
 * Menu is an experimental component for the evolution of DropDown for the
 * upcoming major version 4.x. It includes features like OOTB virtualization
 * for groups.
 *
 * OBS: The component is not functional for all DropDown use cases,
 * this is a WIP.
 */
export declare const Menu: ForwardRef;
export {};
