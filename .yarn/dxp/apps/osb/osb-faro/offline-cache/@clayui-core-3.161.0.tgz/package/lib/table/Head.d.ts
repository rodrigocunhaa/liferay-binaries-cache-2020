/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { ChildrenFunction } from '../collection';
interface IProps<T> extends Omit<React.TableHTMLAttributes<HTMLTableSectionElement>, 'children'> {
    /**
     * Children content to render a dynamic or static content.
     */
    children: React.ReactNode | ChildrenFunction<T, unknown>;
    /**
     * Property to render content with dynamic data.
     */
    items?: Array<T>;
}
export declare function Head<T extends Record<string, any>>({ children, items, ...otherProps }: IProps<T>, ref: React.Ref<HTMLTableSectionElement>): React.JSX.Element;
declare type ForwardRef = {
    <T>(props: IProps<T> & {
        ref?: React.Ref<HTMLTableSectionElement>;
    }): JSX.Element;
    displayName: string;
};
export declare const ForwardHead: ForwardRef;
export {};
