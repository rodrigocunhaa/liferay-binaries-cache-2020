/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { ChildrenFunction as ChildrenFunctionBase } from '../collection';
import { Expand, LoadMore, Selection } from './context';
export declare type ChildrenFunction<T extends Record<string, any>> = ChildrenFunctionBase<T, [Selection, Expand, LoadMore]>;
export interface ICollectionProps<T extends Record<string, any>> {
    children: React.ReactNode | ChildrenFunction<T>;
    /**
     * Property to set the initial value of `items`.
     */
    defaultItems?: Array<T>;
    /**
     * Property to inform the dynamic data of the tree.
     */
    items?: Array<T>;
}
declare type Props = {
    as?: 'div' | React.ComponentType | React.ForwardRefExoticComponent<any>;
};
export declare function Collection<T extends Record<string, any>>({ as, children, items, ...otherProps }: Props & ICollectionProps<T>): React.JSX.Element;
export declare function removeItemInternalProps<T extends Record<any, any>>(props: T): T;
export {};
