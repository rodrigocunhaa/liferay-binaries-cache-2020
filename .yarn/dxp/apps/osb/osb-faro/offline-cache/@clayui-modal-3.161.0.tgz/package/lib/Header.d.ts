/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare function ItemGroup({ children, className, ...otherProps }: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export interface IItemProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Flag for indicating if item should autofitting the width
     */
    shrink?: boolean;
}
export declare function Item({ children, className, shrink, ...otherProps }: IItemProps): React.JSX.Element;
export declare function TitleSection({ children, className, ...otherProps }: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export declare function Title({ children, className, ...otherProps }: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export declare function TitleIndicator({ children, className, ...otherProps }: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export declare function SubtitleSection({ children, className, ...otherProps }: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export declare function Subtitle({ children, className, ...otherProps }: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export interface IHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Aria label for the modal close button.
     */
    closeButtonAriaLabel?: string;
    /**
     * Flag for indicating if you want to use the Header its children being the title.
     * Set to `false` if you want to use this as a low-level component.
     */
    withTitle?: boolean;
}
declare function Header({ children, closeButtonAriaLabel, withTitle, ...otherProps }: IHeaderProps): React.JSX.Element;
export default Header;
