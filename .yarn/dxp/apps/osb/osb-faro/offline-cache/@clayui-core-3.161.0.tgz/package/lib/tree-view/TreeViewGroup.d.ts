/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { ICollectionProps } from './Collection';
interface ITreeViewGroupProps<T extends Record<string, any>> extends ICollectionProps<T>, Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
}
export declare function Group<T extends Record<any, any>>({ children, className, items, ...otherProps }: ITreeViewGroupProps<T>): React.JSX.Element;
export declare namespace Group {
    var displayName: string;
}
export {};
