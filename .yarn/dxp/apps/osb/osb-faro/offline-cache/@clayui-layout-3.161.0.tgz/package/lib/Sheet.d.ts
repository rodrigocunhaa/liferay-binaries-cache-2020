/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IContainerProps extends React.HTMLAttributes<HTMLElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
}
declare const SheetHeader: React.ForwardRefExoticComponent<IContainerProps & React.RefAttributes<HTMLElement>>;
declare const SheetFooter: React.ForwardRefExoticComponent<IContainerProps & React.RefAttributes<HTMLElement>>;
declare const SheetSection: React.ForwardRefExoticComponent<IContainerProps & React.RefAttributes<HTMLElement>>;
declare const SheetRow: React.ForwardRefExoticComponent<IContainerProps & React.RefAttributes<HTMLElement>>;
export interface IProps extends IContainerProps {
    /**
     * Setting this to sets a max-width on the sheet
     */
    size?: 'lg';
}
declare const Sheet: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLElement>>;
export { Sheet, SheetFooter, SheetHeader, SheetSection, SheetRow };
