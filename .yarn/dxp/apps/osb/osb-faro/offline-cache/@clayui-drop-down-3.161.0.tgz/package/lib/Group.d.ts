/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { ICollectionProps } from '@clayui/core';
interface IProps<T> extends Omit<ICollectionProps<T, unknown>, 'virtualize'> {
    /**
     * Value provided is a display component that is a header for the items in the group.
     */
    header?: string;
    /**
     * ARIA to define semantic meaning to content.
     */
    role?: string;
}
declare function Group<T>({ children, header, items, role }: IProps<T>): React.JSX.Element;
declare namespace Group {
    var displayName: string;
}
export default Group;
