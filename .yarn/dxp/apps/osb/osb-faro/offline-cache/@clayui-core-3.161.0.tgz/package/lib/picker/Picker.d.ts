/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import type { ICollectionProps } from '../collection';
export declare type PickerMessages = {
    itemDescribedby: string;
    itemSelected: string;
    noResultsFound: string;
    scrollToBottomAriaLabel: string;
    scrollToTopAriaLabel: string;
    searchPlaceholder: string;
};
declare type Props<T> = {
    /**
     * @ignore
     */
    'UNSAFE_behavior'?: 'secondary';
    /**
     * Sets the className for the React.Portal Menu element.
     */
    'UNSAFE_menuClassName'?: string;
    /**
     * Flag to indicate if the DropDown menu is active or not (controlled).
     */
    'active'?: boolean;
    /**
     * The global `aria-describedby` attribute identifies the element that
     * describes the component.
     */
    'aria-describedby'?: string;
    /**
     * The `aria-label` attribute defines a string value that labels an interactive
     * element.
     */
    'aria-label'?: string;
    /**
     * The `aria-labelledby` attribute identifies the element (or elements) that
     * labels the element it is applied to.
     */
    'aria-labelledby'?: string;
    /**
     * Custom trigger component.
     */
    'as'?: 'button' | React.ForwardRefExoticComponent<any> | ((props: React.HTMLAttributes<HTMLElement>) => JSX.Element);
    /**
     * Sets the CSS className for the component.
     */
    'className'?: string;
    /**
     *  Property to set the default value of `active` (uncontrolled).
     */
    'defaultActive'?: boolean;
    /**
     * The initial selected key (uncontrolled).
     */
    'defaultSelectedKey'?: React.Key;
    /**
     * Direction the menu will render relative to the Picker.
     */
    'direction'?: 'bottom' | 'top';
    /**
     * Flag to indicate that the component is disabled.
     */
    'disabled'?: boolean;
    /**
     * Defines the name of the property key that is used in the items filter
     * test.
     */
    'filterKey'?: string;
    /**
     * The id of the component.
     */
    'id'?: string;
    /**
     * Messages for the Picker.
     */
    'messages'?: Partial<PickerMessages>;
    /**
     * Flag to make the component hybrid, when identified it is on a mobile
     * device it will use the native selector.
     */
    'native'?: boolean;
    /**
     * Callback for when the active state changes (controlled).
     */
    'onActiveChange'?: InternalDispatch<boolean>;
    /**
     * Callback calling when an option is selected.
     */
    'onSelectionChange'?: InternalDispatch<React.Key>;
    /**
     * Text that appears when you don't have an item selected.
     */
    'placeholder'?: string;
    /**
     * Flag to indicate if the component should be searchable.
     */
    'searchable'?: boolean;
    /**
     * The threshold of items to show the search input.
     */
    'searchableThreshold'?: number;
    /**
     * The currently selected key (controlled).
     */
    'selectedKey'?: React.Key;
    /**
     * Flag to make the picker only as wide as its contents.
     */
    'shrink'?: boolean;
    /**
     * Sets the width of the panel.
     */
    'width'?: number;
    [key: string]: any;
} & Omit<ICollectionProps<T, unknown>, 'virtualize'>;
export declare function Picker<T extends Record<string, any> | string | number>({ UNSAFE_behavior, UNSAFE_menuClassName, active: externalActive, as: As, children, className, defaultActive, defaultSelectedKey, direction, disabled, filterKey, id, items, messages: externalMessages, native, onActiveChange, onSelectionChange, placeholder, searchable, searchableThreshold, selectedKey: externalSelectedKey, shrink, width, ...otherProps }: Props<T>): React.JSX.Element;
export {};
