/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import DropDown from '@clayui/drop-down';
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Flag to indicate if menu is showing or not.
     */
    active?: boolean;
    /**
     * HTML element that the menu should be aligned to
     */
    alignElementRef?: React.RefObject<HTMLElement>;
    /**
     * Flag to align the DropDown menu within the viewport.
     */
    alignmentByViewport?: boolean;
    /**
     * Flag to indicate if clicking outside of the menu should automatically close it.
     */
    closeOnClickOutside?: React.ComponentProps<typeof DropDown.Menu>['closeOnClickOutside'];
    /**
     * Callback for when the active state changes (controlled).
     */
    onActiveChange?: InternalDispatch<boolean>;
    /**
     * Callback function for when active state changes.
     * @deprecated since v3.74.0 - use `onActiveChange` instead.
     */
    onSetActive?: (val: boolean) => void;
}
declare function ClayAutocompleteDropDown({ active, alignElementRef, alignmentByViewport, children, closeOnClickOutside, onActiveChange, onSetActive, }: IProps): React.JSX.Element;
declare namespace ClayAutocompleteDropDown {
    var displayName: string;
}
export default ClayAutocompleteDropDown;
