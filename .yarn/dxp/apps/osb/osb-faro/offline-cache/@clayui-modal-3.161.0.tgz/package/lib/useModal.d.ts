/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { Observer } from './types';
declare type Props = {
    /**
     * Set the default value of the state of the modal dialog.
     */
    defaultOpen?: boolean;
    /**
     * Callback called to close the modal.
     * @deprecated since v3.52.0 - use the `open` and `onOpenChange` properties
     * of the hook return and remove its state.
     */
    onClose?: () => void;
};
declare type Return = {
    /**
     * Observer is an internal property that must be connected to the <ClayModal /> component.
     */
    observer: Observer;
    /**
     * Callback to close the modal, aliased to `onOpenChange` callback.
     */
    onClose: () => void;
    /**
     * Callback to change open state.
     */
    onOpenChange: (value: boolean) => void;
    /**
     * Sets the open state of the modal.
     */
    open: boolean;
};
export declare function useModal({ defaultOpen, onClose }?: Props): Return;
export {};
