/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { NetworkStatus, useResource } from './useResource';
declare type ChildrenProps = {
    data: any;
    error: string | boolean;
    loading: boolean;
    networkStatus?: NetworkStatus;
    refetch: Function;
};
interface IProps extends Omit<Parameters<typeof useResource>[0], 'onNetworkStatusChange'> {
    /**
     * It uses a render props pattern made popular by libraries
     * like React Motion and React Router.
     *
     * Children as a function is required for the DataProvider
     * to pass the props with data information, network status,
     * refetch method and others. If this is an impediment try
     * using the `useResource` hook.
     */
    children: (props: ChildrenProps) => React.ReactElement;
    /**
     * Set to true means that network status information will be passed
     * via `renders props` and will also cause new renderings as
     * networkStatus changes, when false rendering does not
     * happen again.
     */
    notifyOnNetworkStatusChange?: boolean;
}
export declare function DataProvider({ children, notifyOnNetworkStatusChange, ...otherProps }: IProps): React.JSX.Element;
export {};
