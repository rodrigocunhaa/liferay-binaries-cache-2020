/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare type TextSize = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
export declare type WeightFont = 'lighter' | 'light' | 'normal' | 'semi-bold' | 'bold' | 'bolder';
export declare type ColorType = null | 'primary' | 'secondary' | 'muted' | 'success' | 'warning' | 'danger' | 'info';
declare type Props = {
    /**
     * State indicates whether the component will be exposed to an
     * accessibility API.
     */
    'aria-hidden'?: boolean;
    /**
     * Determine the way in which a text is displayed.
     */
    'as'?: 'p' | 'span';
    /**
     * Text content.
     */
    'children'?: React.ReactNode;
    /**
     * Determine the color text.
     */
    'color'?: ColorType;
    /**
     * The id global attribute defines an identifier (ID) which must be unique
     * in the whole document.
     */
    'id'?: string;
    /**
     * Set the text in italic style.
     */
    'italic'?: boolean;
    /**
     * Set the text in monospace style.
     */
    'monospace'?: boolean;
    /**
     * Number to set the text size.
     */
    'size'?: TextSize;
    /**
     * Set the text in truncate style.
     */
    'truncate'?: boolean;
    /**
     * Determines the weight of the font.
     */
    'weight'?: WeightFont;
};
export declare function Text({ 'aria-hidden': ariaHidden, as, children, color, id, italic, monospace, size, truncate, weight, }: Props): React.JSX.Element;
export declare namespace Text {
    var displayName: string;
}
export {};
