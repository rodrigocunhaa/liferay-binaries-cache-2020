/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type TColSize = boolean | number | 'auto';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
    /**
     * The number of columns to span on large devices
     */
    lg?: TColSize;
    /**
     * The number of columns to span on medium devices
     */
    md?: TColSize;
    /**
     * The number of columns to span on all devices
     */
    size?: TColSize;
    /**
     * The number of columns to span on small devices
     */
    sm?: TColSize;
    /**
     * The number of columns to span on extra-large devices
     */
    xl?: TColSize;
    /**
     * The number of columns to span on extra-small devices
     */
    xs?: TColSize;
}
declare const Col: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLElement>>;
export default Col;
