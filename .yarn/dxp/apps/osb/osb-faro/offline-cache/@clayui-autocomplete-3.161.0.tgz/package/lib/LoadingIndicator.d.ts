/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Div component to render. It can be a one component that will replace the markup.
     */
    component?: React.ComponentType<any>;
}
declare function ClayAutocompleteLoadingIndicator({ className, component: Component, ...otherProps }: IProps): React.JSX.Element;
export default ClayAutocompleteLoadingIndicator;
