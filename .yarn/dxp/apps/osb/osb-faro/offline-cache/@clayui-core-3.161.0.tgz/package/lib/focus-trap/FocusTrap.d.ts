/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    /**
     * Flag to indicate if the focus trap is activated.
     */
    active: boolean;
    /**
     * The elements that will receive the focus within the focus trap.
     */
    children: React.ReactNode;
    /**
     * Ref of the element that receives the focus when the focus trap is activated.
     */
    focusElementRef?: React.RefObject<HTMLElement>;
    /**
     * Flag that indicates whether the FocusScope stops keyboard event propagation
     * to parent FocusScope components.
     * */
    stopPropagation?: boolean;
};
export declare function FocusTrap({ active, children, focusElementRef, stopPropagation, }: Props): React.JSX.Element;
export {};
