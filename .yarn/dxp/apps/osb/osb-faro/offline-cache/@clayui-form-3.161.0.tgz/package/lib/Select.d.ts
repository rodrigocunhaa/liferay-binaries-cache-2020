/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare function OptGroup({ children, ...otherProps }: React.OptgroupHTMLAttributes<HTMLOptGroupElement>): React.JSX.Element;
export declare function Option({ label, ...otherProps }: React.OptionHTMLAttributes<HTMLOptionElement>): React.JSX.Element;
interface IProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
    /**
     * Flag to make the Select component only as wide as its contents.
     */
    shrink?: boolean;
    /**
     * Set the proportional size of the Select component.
     */
    sizing?: 'lg' | 'sm';
}
declare type SelectComponent = React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLSelectElement>> & {
    OptGroup: typeof OptGroup;
    Option: typeof Option;
};
declare const Select: SelectComponent;
export default Select;
