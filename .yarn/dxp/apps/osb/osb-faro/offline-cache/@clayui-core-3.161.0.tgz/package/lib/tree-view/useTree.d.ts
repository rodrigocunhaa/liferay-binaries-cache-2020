/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { Layout } from './useLayout';
import { IMultipleSelection, IMultipleSelectionState } from './useMultipleSelection';
import type { Key } from 'react';
import type { ICollectionProps } from './Collection';
import type { Position } from './DragAndDrop';
import type { Cursor } from './useLayout';
export interface IExpandable {
    /**
     * Property to set the initial value of `expandedKeys`.
     */
    defaultExpandedKeys?: Set<Key>;
    /**
     * The currently expanded keys in the collection.
     */
    expandedKeys?: Set<Key>;
    /**
     * A callback that is called when items are expanded or collapsed.
     */
    onExpandedChange?: (keys: Set<Key>) => void;
    /**
     * Flag to indicate the hydration phase to expand the selected items. When
     * `selectionMode` is `multiple-recursive` it also revalidates the
     * indeterminate state of the items.
     *
     * It supports two rendering phases, render-first and hydrate after or
     * hydrate before rendering, both have trade-offs that depend on the number
     * of items being rendered.
     *
     * Both cases traverse the tree looking for the selected items to know which
     * items should be expanded and which should be in the indeterminate state,
     * this is done only the first time the component is rendered and if it has
     * selected items. This operation can degrade the performance of the
     * component depending on the number of items, choose the best option for
     * your use case.
     *
     * - `render-first` will render first and then hydrate. It doesn't block the
     * initial rendering but after rendering it is possible to see the items
     * being expanded.
     *
     * - `hydrate-first` will hydrate first and then render. This blocks
     * rendering first until it traverses the tree, when rendered the items
     * are already expanded.
     */
    selectionHydrationMode?: 'render-first' | 'hydrate-first';
}
export interface ITreeProps<T extends Record<string, any>> extends IExpandable, IMultipleSelection, Pick<ICollectionProps<T>, 'items' | 'defaultItems'> {
    /**
     * Flag to indicate which key name matches the nested rendering of the tree.
     */
    nestedKey?: string;
    /**
     * A callback which is called when the property of items is changed.
     */
    onItemsChange?: (items: ICollectionProps<T>['items']) => void;
    selectionMode?: 'single' | 'multiple' | 'multiple-recursive' | null;
}
export interface ITreeState<T extends Record<string, any>> extends Pick<ICollectionProps<T>, 'items'> {
    close: (key: Key) => boolean;
    cursors: React.MutableRefObject<Map<React.Key, unknown>>;
    expandedKeys: Set<Key>;
    insert: (path: Array<number>, value: unknown) => void;
    layout: Layout;
    open: (key: Key) => boolean;
    remove: (path: Array<number>) => void;
    reorder: (keys: Set<Key>, path: Cursor, op: Position) => void;
    replace: (path: Array<number>, item: T) => void;
    selection: IMultipleSelectionState;
    toggle: (key: Key) => void;
}
export declare function useTree<T extends Record<string, any>>(props: ITreeProps<T>): ITreeState<T>;
declare type PatchMove = {
    direction: Position;
    from: Cursor;
    op: 'move';
    path: Cursor;
};
declare type PatchAdd = {
    op: 'add';
    path: Array<number>;
    value: unknown;
};
declare type PatchRemove = {
    op: 'remove';
    path: Array<number>;
};
declare type PatchReplace = {
    item: any;
    op: 'replace';
    path: Array<number>;
};
declare type Patch = PatchMove | PatchAdd | PatchRemove | PatchReplace;
export declare function createImmutableTree<T extends Array<Record<string, any>>>(initialTree: T, nestedKey: string): {
    applyPatches: () => T;
    nodeByPath: (path: Array<number>) => {
        index: number;
        item: {
            [x: string]: any;
        };
        parent: {
            [x: string]: any;
        } | null;
    };
    produce: (patch: Patch) => void;
};
export {};
