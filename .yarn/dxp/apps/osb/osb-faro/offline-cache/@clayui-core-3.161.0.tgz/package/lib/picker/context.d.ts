/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
import type { InternalDispatch } from '@clayui/shared';
declare type PickerContextProps = {
    activeDescendant: React.Key;
    isMobile: boolean;
    onActiveDescendant: (value: React.Key) => void;
    onSelectionChange: InternalDispatch<React.Key>;
    selectedKey: React.Key;
};
export declare const PickerContext: import("react").Context<PickerContextProps>;
export declare function usePickerState(): PickerContextProps;
export {};
