/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IProps extends React.ThHTMLAttributes<HTMLTableCellElement>, React.TdHTMLAttributes<HTMLTableCellElement> {
    /**
     * @ignore
     */
    UNSAFE_resizable?: boolean;
    /**
     * @ignore
     */
    UNSAFE_resizerClassName?: string;
    /**
     * @ignore
     */
    UNSAFE_resizerOnMouseDown?: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
    /**
     * Aligns the text inside the Cell.
     */
    align?: 'center' | 'left' | 'right';
    /**
     * Children content to render content.
     */
    children: React.ReactNode;
    /**
     * Sometimes we are unable to remove specific table columns from the DOM
     * and need to hide it using CSS. This property can be added to the "new"
     * first or last cell to maintain table styles on the left and right side.
     */
    delimiter?: 'start' | 'end';
    /**
     * Fills out the remaining space inside a Cell.
     */
    expanded?: boolean;
    /**
     * @ignore
     */
    index?: number;
    /**
     * @ignore
     */
    keyValue?: React.Key;
    /**
     * Whether the column allows sortable. Only available in the header column.
     */
    sortable?: boolean;
    /**
     * Aligns horizontally contents inside the Cell.
     */
    textAlign?: 'center' | 'end' | 'start';
    /**
     * Sets a text value if the component's content is not plain text.
     */
    textValue?: string;
    /**
     * Truncates the text inside a Cell.
     */
    truncate?: boolean;
    /**
     * Sets the column width.
     */
    width?: string;
    wrap?: boolean;
}
export declare const Cell: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLTableCellElement>>;
export {};
