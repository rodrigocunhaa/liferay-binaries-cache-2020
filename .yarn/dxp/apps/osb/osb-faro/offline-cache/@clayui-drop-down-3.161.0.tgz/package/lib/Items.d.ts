/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare function findNested<T extends {
    items?: Array<T>;
    [key: string]: any;
}, K extends keyof T>(items: Array<T>, key: K): boolean;
declare type Context = {
    back?: () => void;
    close: () => void;
    messages?: Record<string, string>;
    onForward?: (title: string, id: string) => void;
};
export declare const ClayDropDownContext: React.Context<Context>;
export declare type Item = {
    active?: boolean;
    checked?: boolean;
    /**
     * The unique id that references the next menu.
     */
    child?: string;
    disabled?: boolean;
    href?: string;
    items?: Array<Item>;
    /**
     * @deprecated since v3.129.0 - use `title` instead.
     */
    label?: string;
    name?: string;
    onChange?: Function;
    onClick?: (event: React.MouseEvent<HTMLElement, MouseEvent>) => void;
    symbolLeft?: string;
    symbolRight?: string;
    target?: string;
    title?: string;
    type?: 'checkbox' | 'contextual' | 'group' | 'item' | 'radio' | 'radiogroup' | 'divider';
    value?: string;
};
export declare type Props = {
    'aria-label'?: string;
    /**
     * List of items to display in drop down menu
     */
    'items': Array<Item>;
    'role'?: string;
    /**
     * The path to the SVG spritemap file containing the icons.
     */
    'spritemap'?: string;
};
export declare function DropDownItems({ items, role, spritemap, ...otherProps }: Props): React.JSX.Element;
export {};
