/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import { Messages } from './Header';
import { Props as SidePanelProps } from './SidePanel';
export declare type Props = {
    /**
     * Callback is called when the selectedPanelKey prop changes (controlled).
     */
    onSelectedPanelKeyChange: InternalDispatch<string>;
    /**
     * Group of panels to be rendered
     */
    panels: Panels;
    /**
     * Selected panel key
     */
    selectedPanelKey: keyof Panels;
} & Omit<SidePanelProps, 'children'>;
declare type Panel = {
    component: React.ReactNode;
    headerProps?: {
        className?: string;
        messages?: Messages;
        sticky?: boolean;
    };
    parentKey?: string;
    title: string;
};
declare type Panels = {
    [key: string | number | symbol]: Panel;
};
export declare function SidePanelWithDrilldown({ onSelectedPanelKeyChange, panels, selectedPanelKey, ...otherProps }: Props): React.JSX.Element;
export {};
