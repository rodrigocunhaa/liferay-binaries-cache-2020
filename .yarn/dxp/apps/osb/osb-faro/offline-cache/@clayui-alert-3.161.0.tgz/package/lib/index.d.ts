/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { ClayAlertFooter } from './Footer';
import { ClayToastContainer } from './ToastContainer';
export declare type DisplayType = 'danger' | 'info' | 'secondary' | 'success' | 'warning';
export interface IClayAlertProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'role'> {
    /**
     * A React Component to render the alert actions.
     */
    actions?: React.ReactNode;
    /**
     * Flag to indicate alert should automatically call `onClose`. It also
     * accepts a duration (in ms) which indicates how long to wait. If `true`
     * is passed in, the timeout will be 10000ms.
     */
    autoClose?: boolean | number;
    /**
     * Aria label for the dismissable alert close button.
     */
    closeButtonAriaLabel?: string;
    /**
     * Additional class name for the conditional container.
     */
    containerClassName?: string;
    /**
     * Determines the style of the alert.
     */
    displayType?: 'danger' | 'info' | 'secondary' | 'success' | 'warning';
    /**
     * Flag to indicate if close icon should be show. This prop is used in
     * conjunction with the `onClose`prop;
     */
    hideCloseIcon?: boolean;
    /**
     * Callback function for when the 'x' is clicked.
     */
    onClose?: () => void;
    /**
     * The alert role is for important, and usually time-sensitive, information.
     */
    role?: string | null;
    /**
     * Path to the spritemap that Icon should use when referencing symbols.
     */
    spritemap?: string;
    /**
     * The icon's symbol name in the spritemap.
     */
    symbol?: string;
    /**
     * The summary of the Alert, often is something like 'Error' or 'Info'.
     */
    title?: string;
    /**
     * Determines the variant of the alert.
     */
    variant?: 'feedback' | 'stripe' | 'inline';
}
declare function ClayAlert({ actions, autoClose, children, className, closeButtonAriaLabel, containerClassName, displayType, hideCloseIcon, onClose, role, spritemap, symbol, title, variant, ...otherProps }: IClayAlertProps): React.JSX.Element;
declare namespace ClayAlert {
    var displayName: string;
    var Footer: typeof ClayAlertFooter;
    var ToastContainer: typeof ClayToastContainer;
}
export default ClayAlert;
