/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { ICollectionProps } from '../collection';
interface IProps<T> extends ICollectionProps<T, unknown> {
    /**
     * Flag to determine which style the Bar will display.
     */
    displayType?: 'light' | 'dark';
}
export declare function Bar<T>({ children, displayType, items, virtualize, }: IProps<T>): React.JSX.Element;
export {};
