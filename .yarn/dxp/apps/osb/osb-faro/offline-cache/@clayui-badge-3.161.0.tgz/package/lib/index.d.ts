/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare const ItemAfter: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
export declare const ItemBefore: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
export declare const ItemExpand: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
declare type DisplayType = 'primary' | 'secondary' | 'info' | 'danger' | 'success' | 'warning' | 'beta' | 'beta-dark';
interface IProps extends React.HTMLAttributes<HTMLSpanElement> {
    /**
     * Flag to indicate if the badge should use the clay-dark variant.
     */
    dark?: boolean;
    /**
     * Determines the color of the badge.
     * The values `beta` and `beta-dark` are deprecated since v3.100.0 - use
     * `translucent` and `dark` instead.
     */
    displayType?: DisplayType;
    /**
     * Info that is shown inside of the badge itself.
     */
    label?: string | number;
    /**
     * Path to the location of the spritemap resource.
     */
    spritemap?: string;
    /**
     * The id of the icon in the spritemap.
     */
    symbol?: string;
    /**
     * Flag to indicate if the badge should use the translucent variant.
     */
    translucent?: boolean;
}
declare const Badge: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLSpanElement>> & {
    ItemAfter: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
    ItemBefore: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
    ItemExpand: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
};
export default Badge;
