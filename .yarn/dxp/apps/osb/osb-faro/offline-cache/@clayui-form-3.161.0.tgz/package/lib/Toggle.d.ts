/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IToggleProps extends React.InputHTMLAttributes<HTMLInputElement> {
    containerProps?: React.HTMLAttributes<HTMLSpanElement>;
    disabled?: boolean;
    id?: string;
    label?: React.ReactText;
    onToggle?: (val: boolean) => void;
    sizing?: string;
    spritemap?: string;
    symbol?: {
        off: string;
        on: string;
    };
    toggled?: boolean;
    type?: 'checkbox' | 'radio';
    value?: string;
}
declare const Toggle: React.ForwardRefExoticComponent<IToggleProps & React.RefAttributes<HTMLLabelElement>>;
export default Toggle;
