/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { ChildrenFunction } from '../collection';
interface IProps<T> extends Omit<React.HTMLAttributes<HTMLTableRowElement>, 'children'> {
    /**
     * @ignore
     */
    _expandable?: boolean;
    /**
     * @ignore
     */
    _index?: number;
    /**
     * @ignore
     */
    _item?: T;
    /**
     * @ignore
     */
    _level?: number;
    /**
     * @ignore
     */
    _loc?: Array<number>;
    /**
     * @ignore
     */
    _size?: number;
    /**
     * Children content to render a dynamic or static content.
     */
    children: React.ReactNode | ChildrenFunction<T, unknown>;
    /**
     * This property can be added to the "new" first
     * or last ClayTable.Row to maintain table styles on the top and bottom sides.
     */
    delimiter?: 'start' | 'end';
    /**
     * Applies a divider style inside the row.
     */
    divider?: boolean;
    /**
     * Property to render content with dynamic data.
     */
    items?: Array<T>;
    /**
     * @ignore
     */
    keyValue?: React.Key;
    /**
     * Flag to indicate that the row has children to be loaded lazily when
     * `onLoadMore` is set.
     */
    lazy?: boolean;
}
export declare function Row<T extends Record<string, any>>({ _expandable, _index, _item, _level, _loc, _size, children, className, delimiter, divider, items, keyValue, lazy, ...otherProps }: IProps<T>, outRef: React.Ref<HTMLTableRowElement>): React.JSX.Element;
declare type ForwardRef = {
    <T>(props: IProps<T> & {
        ref?: React.Ref<HTMLTableRowElement>;
    }): JSX.Element;
    displayName: string;
};
export declare const ForwardRow: ForwardRef;
export {};
