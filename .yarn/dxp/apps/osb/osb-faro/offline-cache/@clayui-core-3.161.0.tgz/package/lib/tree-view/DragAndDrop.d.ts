/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { MoveItemIndex } from './context';
import { Layout } from './useLayout';
export declare type DragAndDropMessages = {
    dragDescriptionKeyboard: string;
    dragItem: string;
    dragLayerPluralLabel: string;
    dragStartedKeyboard: string;
    dropCanceled: string;
    dropComplete: string;
    dropDescriptionKeyboard: string;
    dropIndicator: string;
    dropOn: string;
    endDragKeyboard: string;
    insertAfter: string;
    insertBefore: string;
};
export declare type Value = {
    cursor: Array<React.Key>;
    indexes: Array<number>;
    itemRef: React.RefObject<HTMLDivElement>;
    key: React.Key;
    nextKey?: React.Key;
    parentItemRef: React.RefObject<HTMLDivElement>;
    prevKey?: React.Key;
    [propName: string]: any;
};
declare type ContextProps = {
    /**
     * Key of the item from which the drag interaction was initiated.
     * This is the item the user clicked to start dragging, even when
     * multiple items are selected.
     */
    currentDrag: React.Key | null;
    /**
     * Set of keys representing all selected items being dragged together.
     * Includes the drag origin item and any other selected items.
     */
    currentDragKeys: Set<React.Key>;
    currentTarget: React.Key | null;
    dragCancelDescribedBy: string;
    dragDescribedBy: string;
    dragDropDescribedBy: string;
    messages: DragAndDropMessages;
    onCancel: () => void;
    onClearPosition: () => void;
    onDragStart: (source: 'keyboard' | 'mouse', target: React.Key) => void;
    onDrop: () => void;
    onEnd: (status?: 'complete' | 'canceled' | null) => void;
    onPositionChange: (key: React.Key, position: Position) => void;
    position: Position | null;
    source: 'keyboard' | 'mouse' | null;
};
declare type State = Pick<ContextProps, 'currentDrag' | 'currentDragKeys' | 'currentTarget' | 'position' | 'source'> & {
    lastItem: React.Key | null;
    status: 'complete' | 'canceled' | null;
};
declare type Props<T> = {
    children: React.ReactNode;
    messages?: DragAndDropMessages;
    mode: 'single' | 'multiple';
    nestedKey: string;
    onItemHover?: (items: T | Set<React.Key>, parentItem: T, index: MoveItemIndex, position: Position) => boolean;
    onItemMove?: (items: T | Set<React.Key>, parentItem: T, index: MoveItemIndex) => boolean;
    rootRef: React.RefObject<HTMLUListElement>;
};
export declare function removeDescendants(currentDragKeys: Set<React.Key>, layout: Layout): Set<React.Key>;
export declare function isDescendantOfDraggedItems({ dragKeys, element, rootRef, }: {
    dragKeys: State['currentDragKeys'];
    element: Element;
    rootRef: React.RefObject<HTMLUListElement>;
}): boolean;
export declare function DragAndDropProvider<T>({ children, messages, mode, nestedKey, onItemMove, onItemHover, rootRef, }: Props<T>): React.JSX.Element;
export declare const TARGET_POSITION: {
    readonly BOTTOM: "bottom";
    readonly MIDDLE: "middle";
    readonly TOP: "top";
};
declare type ValueOf<T> = T[keyof T];
export declare type Position = ValueOf<typeof TARGET_POSITION>;
export declare function getNewItemPath(path: Array<number>, overPosition: Position): number[];
export declare function useDnD(): ContextProps;
export {};
