/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import ClayButton from './Button';
interface ICommonProps extends Omit<React.ComponentProps<typeof ClayButton>, 'aria-label' | 'aria-labelledby'> {
    'aria-label'?: string;
    'aria-labelledby'?: string;
    /**
     * Path to the location of the spritemap resource.
     */
    'spritemap'?: string;
    /**
     * The id of the icon in the spritemap.
     */
    'symbol': string;
}
export declare type Props = ICommonProps;
declare const ClayButtonWithIcon: React.ForwardRefExoticComponent<Omit<ICommonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
export default ClayButtonWithIcon;
