/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { ClayDropDownWithItems } from '@clayui/drop-down';
import React from 'react';
/**
 * @deprecated since v3.84.0 - use `Picker` component instead.
 */
/**
 * @deprecated since v3.84.0 - use `Picker` component instead.
 */
export declare function DropDown({ className, messages, trigger, ...otherProps }: React.ComponentProps<typeof ClayDropDownWithItems>): React.JSX.Element;
