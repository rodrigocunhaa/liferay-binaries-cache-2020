/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
/**
 * Helper function to create a unique key for list or tree when defined by
 * developer data or obtained by component in React.
 */
export declare function getKey(index: number, key?: React.Key | null, parentKey?: React.Key): import("react").Key;
/**
 * Helper function for omitting properties of an object, similar to
 * TypeScript's Omit<T, K>.
 */
export declare function excludeProps<T extends Record<string, any>, K extends keyof T>(props: T, items: Set<K>): T;
