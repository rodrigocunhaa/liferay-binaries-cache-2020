/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { AlignPoints, InternalDispatch } from '@clayui/shared';
import React from 'react';
import { Pagination } from './Pagination';
interface IProps extends React.ComponentProps<typeof Pagination> {
    /**
     * Sets the currently active page (controlled).
     */
    active?: number;
    /**
     * The page that is currently active. The first page is `1`.
     * @deprecated since v3.49.0 - use `active` instead.
     */
    activePage?: number;
    /**
     * Sets the default DropDown position of the component. The component
     * receives the Align constant values from the `@clayui/drop-down` package.
     */
    alignmentPosition?: number | AlignPoints;
    /**
     * Labels for the aria attributes
     */
    ariaLabels?: {
        link: string;
        next: string;
        previous: string;
    };
    /**
     * Sets the default active page (uncontrolled).
     */
    defaultActive?: number;
    /**
     * Flag to disable ellipsis button
     */
    disableEllipsis?: boolean;
    /**
     * The page numbers that should be disabled. For example, `[2,5,6]`.
     */
    disabledPages?: Array<number>;
    /**
     * The number of pages to show on each side of the active page before
     * using an ellipsis dropdown.
     */
    ellipsisBuffer?: number;
    /**
     * Properties to pass to the ellipsis trigger.
     */
    ellipsisProps?: {} | undefined;
    /**
     * Function used to create the href provided for each page link.
     */
    hrefConstructor?: (page?: number) => string;
    /**
     * Callback called when the state of the active page changes (controlled).
     * This is only used if an href is not provided.
     */
    onActiveChange?: InternalDispatch<number>;
    /**
     * Callback for when the active page changes. This is only used if
     * an href is not provided.
     * @deprecated since v3.49.0 - use `onActiveChange` instead.
     */
    onPageChange?: InternalDispatch<number>;
    /**
     * Path to spritemap from clay-css.
     */
    spritemap?: string;
    /**
     * The total number of pages in the pagination list.
     */
    totalPages: number;
}
export declare const ClayPaginationWithBasicItems: React.ForwardRefExoticComponent<Omit<IProps, "ref"> & React.RefAttributes<HTMLUListElement>>;
export {};
