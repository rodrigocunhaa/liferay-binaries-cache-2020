/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IRadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
    /**
     * Props for the outer most container element.
     */
    containerProps?: React.HTMLAttributes<HTMLDivElement>;
    /**
     * Flag to indicate if radio elements should display inline.
     */
    inline?: boolean;
    /**
     * Text to describe for radio element.
     */
    label?: React.ReactText;
    /**
     * Value provided if element is selected.
     */
    value: React.ReactText;
}
declare const Radio: React.ForwardRefExoticComponent<IRadioProps & React.RefAttributes<HTMLInputElement>>;
export default Radio;
