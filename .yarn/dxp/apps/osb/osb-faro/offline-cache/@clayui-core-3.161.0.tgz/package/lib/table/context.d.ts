/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare type Sorting = {
    column: React.Key;
    direction: 'ascending' | 'descending';
};
declare type Context = {
    alwaysVisibleColumns: Set<React.Key>;
    columnsVisibility: boolean;
    expandedKeys: Set<React.Key>;
    headCellsCount: number;
    itemIdKey: string;
    messages: Record<string, string>;
    nestedKey?: string;
    onExpandedChange: (keys: Set<React.Key>) => void;
    onHeadCellsChange: (value: number) => void;
    onLoadMore?: (item: unknown) => Promise<Array<any> | undefined>;
    onSortChange: (sorting: Sorting | null, textValue: string) => void;
    onVisibleColumnsChange: (column: React.Key | Array<React.Key>, index: number) => void;
    sort: Sorting | null;
    sortDescriptionId: string;
    treegrid: boolean;
    visibleColumns: Map<React.Key, number>;
};
export declare const TableContext: React.Context<Context>;
export declare function useTable(): Context;
declare type RowContext = {
    divider: boolean;
    expandable?: boolean;
    isLoading: boolean;
    key: React.Key;
    lazy: boolean;
    level: number;
    loadMore: () => void;
};
export declare const RowContext: React.Context<RowContext>;
export declare function useRow(): RowContext;
declare type BodyContext = {
    insert: (path: Array<number>, value: unknown) => void;
};
export declare const BodyContext: React.Context<BodyContext>;
export declare function useBody(): BodyContext;
export {};
