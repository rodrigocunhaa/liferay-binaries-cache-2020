/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare const QuickActionMenu: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>> & {
    Item: React.ForwardRefExoticComponent<import("./QuickActionMenuItem").IItemProps & React.RefAttributes<HTMLAnchorElement & HTMLButtonElement>>;
};
export default QuickActionMenu;
