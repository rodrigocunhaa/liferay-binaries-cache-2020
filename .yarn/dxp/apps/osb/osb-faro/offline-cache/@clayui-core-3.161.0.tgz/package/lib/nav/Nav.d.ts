/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { Item } from './Item';
export interface IPropsNav extends React.HTMLAttributes<HTMLUListElement> {
    /**
     * Flag to indicate if `nav-nested-margins` class should be applied. Adds margin to indent each nested navigation.
     */
    nestMargins?: boolean;
    /**
     * Flag to indicate if `nav-nested` class should be applied. Adds padding to indent each nested navigation.
     */
    nested?: boolean;
    /**
     * Flag to indicate if `nav-stacked` class should be applied.
     */
    stacked?: boolean;
}
export declare const Nav: React.ForwardRefExoticComponent<IPropsNav & React.RefAttributes<HTMLUListElement>> & {
    Item: typeof Item;
    Link: React.ForwardRefExoticComponent<import("./Link").IPropsLink & React.RefAttributes<HTMLAnchorElement | HTMLButtonElement | HTMLDivElement>>;
};
