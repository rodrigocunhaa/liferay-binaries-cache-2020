/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
declare type AlignBase = {
    offset?: readonly [number, number];
    overflow?: {
        adjustX: boolean;
        adjustY: boolean;
        alwaysByViewport?: boolean;
    };
    points?: readonly [string, string];
    targetOffset?: readonly [string, string];
};
declare type AlignProps<T, K> = AlignBase & {
    sourceElement: K;
    targetElement: T;
};
export declare function doAlign<T extends HTMLElement, K extends HTMLElement>({ sourceElement, targetElement, ...config }: AlignProps<T, K>): Required<AlignBase>;
export {};
