/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface ITreeViewItemProps extends Omit<React.HTMLAttributes<HTMLLIElement>, 'children'> {
    /**
     * Property for rendering actions on a Node.
     */
    actions?: React.ReactElement;
    /**
     * Flag to set the node to the active state.
     */
    active?: boolean;
    /**
     * Item content.
     */
    children: React.ReactNode;
    /**
     * Flag indicating that the component is disabled.
     */
    disabled?: boolean;
    /**
     * Flag to define if the item is draggable and dropable.
     */
    draggable?: boolean;
    /**
     * Flag to indicate if the item is expandable. This renders the arrow
     * button on the item.
     */
    expandable?: boolean;
    /**
     * @ignore
     */
    isDragging?: boolean;
    /**
     * Flag to remove the visual of the hover over the item.
     */
    noHover?: boolean;
    /**
     * @ignore
     */
    overPosition?: string;
    /**
     * @ignore
     */
    overTarget?: boolean;
}
export declare const Item: React.ForwardRefExoticComponent<ITreeViewItemProps & React.RefAttributes<HTMLDivElement>>;
interface ITreeViewItemStackProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * @ignore
     */
    actions?: React.ReactElement;
    /**
     * Flag to set the node to the active state.
     */
    active?: boolean;
    /**
     * Item content.
     */
    children: React.ReactNode;
    /**
     * Flag indicating that the component is disabled.
     */
    disabled?: boolean;
    /**
     * Flag to define if the item is draggable and dropable.
     */
    draggable?: boolean;
    /**
     * Flag to indicate if the item should be expanded when clicking the
     * node itself (not the expander)
     */
    expandOnClick?: boolean;
    /**
     * Flag to indicate if the item is expandable. This renders the arrow
     * button on the item.
     */
    expandable?: boolean;
    /**
     * Flag indicating if Expander is disabled, by default it has the
     * value of the disabled prop.
     */
    expanderDisabled?: boolean;
    /**
     * @ignore
     */
    isNonDraggrable?: boolean;
    /**
     * @ignore
     */
    labelId?: string;
    /**
     * @ignore
     */
    loading?: boolean;
    /**
     * Flag to remove the visual of the hover over the item.
     */
    noHover?: boolean;
    /**
     * @ignore
     */
    onLoadMore?: () => void;
    /**
     * @ignore
     */
    tabIndex?: number;
}
export declare function ItemStack({ actions, children, disabled, expandable, expanderDisabled, isNonDraggrable, labelId, loading, onLoadMore, tabIndex, ...otherProps }: ITreeViewItemStackProps): React.JSX.Element;
export declare namespace ItemStack {
    var displayName: string;
}
export {};
