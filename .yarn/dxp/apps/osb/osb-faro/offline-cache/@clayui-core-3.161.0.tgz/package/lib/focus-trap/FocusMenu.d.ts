/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type FocusMenuProps<T, E extends HTMLElement> = {
    children: T;
    focusableElements?: Array<string>;
    menuRef: React.MutableRefObject<E> | React.RefObject<E>;
};
/**
 * TODO: Move the implementation to be part of the useNavigation hook so that
 * it is an internal function that can be called to focus on the first item.
 */
export declare function FocusMenu<T, E extends HTMLElement>({ children, menuRef, focusableElements, }: FocusMenuProps<T, E>): JSX.Element;
export {};
