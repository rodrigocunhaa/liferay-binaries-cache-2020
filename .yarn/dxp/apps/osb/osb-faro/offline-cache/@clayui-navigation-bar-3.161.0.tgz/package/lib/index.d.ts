/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import ClayLayout from '@clayui/layout';
import React from 'react';
import { Item } from './Item';
export interface IProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'aria-current'> {
    /**
     * Children elements received from ClayNavigationBar component.
     */
    children: Array<React.ReactElement<React.ComponentProps<typeof Item>>> | React.ReactElement<React.ComponentProps<typeof Item>>;
    /**
     * Set a maximum width on container-fluid.
     */
    fluidSize?: React.ComponentProps<typeof ClayLayout.Container>['fluidSize'] | false;
    /**
     * Determines the style of the Navigation Bar
     */
    inverted?: boolean;
    /**
     * Flag to define if the item represents the current page. Disable this
     * attribute only if there are multiple navigations on the page.
     */
    itemAriaCurrent?: boolean;
    /**
     * Messages for the Navigation Bar.
     */
    messages?: {
        close: 'Close';
        open: 'Open';
        trigger: '{0} Menu, Current Page: {1}';
    };
    /**
     * Path to the location of the spritemap resource.
     */
    spritemap?: string;
    /**
     * Set up dropdown's trigger label.
     */
    triggerLabel: string;
}
declare function NavigationBar({ children, className, fluidSize, inverted, itemAriaCurrent: ariaCurrent, messages, spritemap, triggerLabel, ...otherProps }: IProps): React.JSX.Element;
declare namespace NavigationBar {
    var Item: typeof import("./Item").Item;
}
export default NavigationBar;
