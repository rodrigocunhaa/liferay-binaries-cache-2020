/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { DropDown } from './DropDown';
import { Results } from './Results';
interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * The size of pagination element.
     */
    size?: 'sm' | 'lg';
}
export declare const PaginationBar: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLDivElement>> & {
    DropDown: typeof DropDown;
    Results: typeof Results;
};
export {};
