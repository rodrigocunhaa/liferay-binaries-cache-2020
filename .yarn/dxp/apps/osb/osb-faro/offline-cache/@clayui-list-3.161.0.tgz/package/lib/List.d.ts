/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLUListElement> {
    children?: React.ReactElement<React.HTMLAttributes<HTMLLIElement>> | Array<React.ReactElement<React.HTMLAttributes<HTMLLIElement>>>;
    showQuickActionsOnHover?: boolean;
}
declare function List({ children, className, showQuickActionsOnHover, ...otherProps }: IProps): React.JSX.Element;
declare namespace List {
    var displayName: string;
    var Header: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLLIElement> & React.RefAttributes<HTMLLIElement>>;
    var Item: React.ForwardRefExoticComponent<import("./Item").IProps & React.RefAttributes<HTMLLIElement>>;
    var ItemField: React.ForwardRefExoticComponent<import("@clayui/layout/lib/Content").IContentColProps & React.RefAttributes<HTMLElement>>;
    var ItemText: React.ForwardRefExoticComponent<import("./ItemText").IProps & React.RefAttributes<HTMLParagraphElement>>;
    var ItemTitle: React.ForwardRefExoticComponent<React.BaseHTMLAttributes<HTMLAnchorElement> & React.RefAttributes<HTMLDivElement>>;
    var QuickActionMenu: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>> & {
        Item: React.ForwardRefExoticComponent<import("./QuickActionMenuItem").IItemProps & React.RefAttributes<HTMLAnchorElement & HTMLButtonElement>>;
    };
}
export default List;
