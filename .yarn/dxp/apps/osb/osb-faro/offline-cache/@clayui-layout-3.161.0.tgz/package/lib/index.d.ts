/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
import Col from './Col';
import Container from './Container';
import ContainerFluid from './ContainerFluid';
import { ContentCol, ContentRow, ContentSection } from './Content';
import Row from './Row';
import { Sheet, SheetFooter, SheetHeader, SheetRow, SheetSection } from './Sheet';
export { Col, Container, ContainerFluid, ContentCol, ContentRow, ContentSection, Row, Sheet, SheetFooter, SheetHeader, SheetSection, SheetRow, };
declare function ClayLayout(): null & {
    Col: typeof Col;
    Container: typeof Container;
    ContainerFluid: typeof ContainerFluid;
    ContentCol: typeof ContentCol;
    ContentRow: typeof ContentRow;
    ContentSection: typeof ContentSection;
    Row: typeof Row;
    Sheet: typeof Sheet;
    SheetFooter: typeof SheetFooter;
    SheetHeader: typeof SheetHeader;
    SheetRow: typeof SheetRow;
    SheetSection: typeof SheetSection;
};
declare namespace ClayLayout {
    var Col: import("react").ForwardRefExoticComponent<import("./Col").IProps & import("react").RefAttributes<HTMLElement>>;
    var Container: import("react").ForwardRefExoticComponent<import("./Container").IProps & import("react").RefAttributes<HTMLElement>>;
    var ContainerFluid: import("react").ForwardRefExoticComponent<Omit<import("./ContainerFluid").IProps, "ref"> & import("react").RefAttributes<HTMLElement>>;
    var ContentCol: import("react").ForwardRefExoticComponent<import("./Content").IContentColProps & import("react").RefAttributes<HTMLElement>>;
    var ContentRow: import("react").ForwardRefExoticComponent<import("./Content").IContentRowProps & import("react").RefAttributes<HTMLElement>>;
    var ContentSection: import("react").ForwardRefExoticComponent<import("./Content").IColSectionProps & import("react").RefAttributes<HTMLElement>>;
    var Row: import("react").ForwardRefExoticComponent<import("./Row").IProps & import("react").RefAttributes<HTMLElement>>;
    var Sheet: import("react").ForwardRefExoticComponent<import("./Sheet").IProps & import("react").RefAttributes<HTMLElement>>;
    var SheetFooter: import("react").ForwardRefExoticComponent<import("./Sheet").IContainerProps & import("react").RefAttributes<HTMLElement>>;
    var SheetHeader: import("react").ForwardRefExoticComponent<import("./Sheet").IContainerProps & import("react").RefAttributes<HTMLElement>>;
    var SheetSection: import("react").ForwardRefExoticComponent<import("./Sheet").IContainerProps & import("react").RefAttributes<HTMLElement>>;
    var SheetRow: import("react").ForwardRefExoticComponent<import("./Sheet").IContainerProps & import("react").RefAttributes<HTMLElement>>;
}
export default ClayLayout;
