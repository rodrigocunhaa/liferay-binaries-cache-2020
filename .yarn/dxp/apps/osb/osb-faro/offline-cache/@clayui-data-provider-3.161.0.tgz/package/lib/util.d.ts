/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/**
 * Implementation of the timeout.
 * Based on: https://github.com/github/fetch/issues/175#issuecomment-125779262
 */
/**
 * Implementation of the timeout.
 * Based on: https://github.com/github/fetch/issues/175#issuecomment-125779262
 */
export declare function timeout(ms: number, promise: Promise<any>, controller?: AbortController): Promise<unknown>;
/**
 * Generates a unique identifier from a request, using the request data like
 * URL, body, headers... from an HTTP request.
 */
/**
 * Generates a unique identifier from a request, using the request data like
 * URL, body, headers... from an HTTP request.
 */
export declare function getIdentifier(link: string, variables: Record<string, any> | null, options?: RequestInit): string;
