/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    /**
     * The panel content.
     */
    children: React.ReactNode;
    /**
     * Internal property.
     * @ignore
     */
    keyValue?: React.Key | null;
    /**
     * Indicates whether the panel can be focused.
     */
    tabIndex?: number;
};
export declare function Panel({ children, keyValue, tabIndex }: Props): React.JSX.Element;
export {};
