/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React, { Key } from 'react';
import { Position } from './DragAndDrop';
import type { ChildrenFunction } from './Collection';
import type { ITreeState } from './useTree';
export declare type Icons = {
    close: React.ReactElement;
    open: React.ReactElement;
};
declare type LoadMoreCursor = {
    cursor: unknown;
    items: Array<unknown>;
};
export declare type OnLoadMore<T> = (item: T, cursor?: any) => Promise<Array<any> | undefined> | Promise<LoadMoreCursor | undefined>;
export declare type MoveItemIndex = {
    next: number;
    previous: number;
};
export interface ITreeViewContext<T extends Record<string, any>> extends ITreeState<T> {
    childrenRoot: React.MutableRefObject<ChildrenFunction<Object> | null>;
    dragAndDrop?: boolean;
    dragAndDropMode: 'single' | 'multiple';
    dragHandlerVisibility?: 'visible' | 'keyboard';
    expandDoubleClick?: boolean;
    expandOnCheck?: boolean;
    expanderClassName?: string;
    expanderIcons?: Icons;
    itemNameKey?: string;
    nestedKey?: string;
    onItemHover?: (items: T | Set<Key>, parentItem: T, index: MoveItemIndex, position: Position) => boolean;
    onItemInvalidMove?: () => void;
    onItemMove?: (items: T | Set<Key>, parentItem: T, index: MoveItemIndex) => boolean;
    onLoadMore?: OnLoadMore<T>;
    onRenameItem?: (item: T) => Promise<any>;
    onSelect?: (item: T) => void;
    rootRef: React.RefObject<HTMLUListElement>;
    selectionMode?: 'single' | 'multiple' | 'multiple-recursive' | null;
    showExpanderOnHover?: boolean;
    spritemap?: string;
}
export declare const TreeViewContext: React.Context<ITreeViewContext<any>>;
export declare function useTreeViewContext(): ITreeViewContext<Record<string, any>>;
declare type SelectionToggleOptions = {
    parentSelection?: boolean;
    selectionMode?: 'single' | 'multiple' | 'multiple-recursive' | null;
};
export declare type Selection = {
    has: (key: Key) => boolean;
    toggle: (key: Key, options?: SelectionToggleOptions) => void;
};
export declare type Expand = {
    has: (key: Key) => boolean;
    toggle: (key: Key) => void;
};
export declare type LoadMore = {
    get: (key: Key) => any;
    loadMore: <T extends Record<string, any>>(id: React.Key, item: T, willToggle?: boolean) => Promise<void> | undefined;
};
export declare function useAPI(): [Selection, Expand, LoadMore];
export {};
