/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IProps extends React.HTMLAttributes<HTMLElement> {
    /**
     * Adds a helper class that turns the Toolbar inline at a specified breakpoint.
     */
    inlineBreakpoint?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
    /**
     * Determines if the tbar-light class should be added to the Toolbar, making it's background white.
     */
    light?: boolean;
    /**
     * Defines if the toolbar should have the `subnav-tbar` class.
     */
    subnav?: boolean | {
        disabled?: boolean;
        displayType?: 'light' | 'primary';
    };
}
declare function Toolbar({ children, className, inlineBreakpoint, light, subnav, ...otherProps }: IProps): React.JSX.Element;
declare namespace Toolbar {
    var Action: typeof import("./Action").Action;
    var Item: typeof import("./Item").Item;
    var Input: typeof import("./Input").Input;
    var Label: typeof import("./Label").Label;
    var Link: typeof import("./Link").Link;
    var Nav: typeof import("./Nav").Nav;
    var Section: typeof import("./Section").Section;
}
export default Toolbar;
