/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { IPortalBaseProps } from '@clayui/shared';
import React from 'react';
import { IContext } from './Context';
import { Observer } from './types';
interface IProps extends React.HTMLAttributes<HTMLDivElement>, Omit<IContext, 'onClose' | 'ariaLabelledby'> {
    /**
     * Flag indicating to vertically center the modal.
     */
    center?: boolean;
    /**
     * Container element to render modal into.
     */
    containerElementRef?: React.RefObject<Element>;
    /**
     * Props to add to the ClayPortal.
     */
    containerProps?: IPortalBaseProps;
    /**
     * A flag indicating if the modal shouldn't
     * be closed when either the ESC key is pressed
     * or when clicking outside the modal
     */
    disableAutoClose?: boolean;
    /**
     * Observer is Modal's communication system with `useModal`
     * hook, adds observer from `useModal` hook here.
     */
    observer: Observer;
    /**
     * The size of element modal.
     */
    size?: 'full-screen' | 'lg' | 'sm';
    /**
     * Allows setting a custom z-index value, overriding the default one which is 1040, modal body z-index will be +10 of this value
     */
    zIndex?: number;
}
declare function Modal({ center, children, className, containerElementRef, containerProps, disableAutoClose, observer, role, size, spritemap, status, zIndex, ...otherProps }: IProps): React.JSX.Element;
declare namespace Modal {
    var Body: typeof import("./Body").default;
    var Footer: typeof import("./Footer").default;
    var Header: typeof import("./Header").default;
    var Item: typeof import("./Header").Item;
    var ItemGroup: typeof import("./Header").ItemGroup;
    var Subtitle: typeof import("./Header").Subtitle;
    var SubtitleSection: typeof import("./Header").SubtitleSection;
    var Title: typeof import("./Header").Title;
    var TitleIndicator: typeof import("./Header").TitleIndicator;
    var TitleSection: typeof import("./Header").TitleSection;
}
export default Modal;
