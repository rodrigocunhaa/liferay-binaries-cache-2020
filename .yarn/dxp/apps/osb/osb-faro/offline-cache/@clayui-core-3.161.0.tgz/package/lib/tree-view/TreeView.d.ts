/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { ICollectionProps } from './Collection';
import { DragAndDropMessages, Position } from './DragAndDrop';
import { Icons, MoveItemIndex, OnLoadMore } from './context';
import { ITreeProps } from './useTree';
interface ITreeViewProps<T extends Record<string, any>> extends Omit<React.HTMLAttributes<HTMLUListElement>, 'children' | 'onSelect'>, ITreeProps<T>, ICollectionProps<T> {
    /**
     * Flag to determine which style the TreeView will display.
     */
    displayType?: 'light' | 'dark';
    /**
     * Flag to enable Drag and Drop of Nodes over the Tree.
     */
    dragAndDrop?: boolean;
    /**
     * Optional drag and drop context: this is to avoid
     * errors when using various drag and drop contexts
     * on the same page.
     */
    dragAndDropContext?: Window & typeof globalThis;
    /**
     * Flag changes the behavior of Drag and Drop functionality.
     * - single: allows dragging only one node.
     * - multiple: several nodes can be dragged at once.
     */
    dragAndDropMode?: 'multiple' | 'single';
    /**
     * Flag to control drag handler visibility.
     */
    dragHandlerVisibility?: 'keyboard' | 'visible';
    /**
     * Flag to expand the node's children when double-clicking the node.
     */
    expandDoubleClick?: boolean;
    /**
     * Flag to expand child nodes when a parent node is checked.
     */
    expandOnCheck?: boolean;
    /**
     * Extra classes passed to the expander button.
     */
    expanderClassName?: string;
    /**
     * Flag to modify Node expansion state icons.
     */
    expanderIcons?: Icons;
    /**
     * Flag to indicate which key name matches the item name to be displayed
     * in drag preview.
     */
    itemNameKey?: string;
    /**
     * Messages that the TreeView uses to announce to the screen reader. Use
     * this to handle internationalization.
     */
    messages?: DragAndDropMessages;
    /**
     * The callback is called whenever there is an item dragging over
     * another item.
     */
    onItemHover?: (items: T | Set<React.Key>, parentItem: T, index: MoveItemIndex, position: Position) => boolean;
    /**
     * Callback is called when an item move is rejected.
     */
    onItemInvalidMove?: () => void;
    /**
     * Callback is called when an item is about to be moved elsewhere in the tree.
     */
    onItemMove?: (items: T | Set<React.Key>, parentItem: T, index: MoveItemIndex) => boolean;
    /**
     * When a tree is very large, loading items (nodes) asynchronously is preferred to
     * decrease the initial payload and memory space. The callback is called every time
     * the item is a leaf node of the tree.
     */
    onLoadMore?: OnLoadMore<T>;
    /**
     * Calback is called when the user presses the R or F2 hotkey.
     */
    onRenameItem?: (item: T) => Promise<T>;
    /**
     * Callback called whenever an item is selected. Similar to the `onSelectionChange`
     * callback but instead of passing the selected keys it is called with the current
     * item being selected.
     */
    onSelect?: (item: T) => void;
    /**
     * Flag changes the Node selection behavior when a checkbox is rendered on the Node.
     * - single: select only node.
     * - multiple: select multiple nodes.
     * - multiple-recursive: selects multiple nodes and recursively.
     */
    selectionMode?: 'single' | 'multiple' | 'multiple-recursive' | null;
    /**
     * Flag to indicate if the TreeView will show the expander in the hover in the Node.
     */
    showExpanderOnHover?: boolean;
    /**
     * Path to the spritemap that Icon should use when referencing symbols.
     */
    spritemap?: string;
}
export declare function TreeView<T extends Record<string, any>>({ children, className, defaultExpandedKeys, defaultItems, defaultSelectedKeys, displayType, dragAndDrop, dragAndDropContext, dragAndDropMode, dragHandlerVisibility, expandDoubleClick, expandedKeys, expanderClassName, expanderIcons, expandOnCheck, indeterminate, itemNameKey, items, messages, nestedKey, onExpandedChange, onItemHover, onItemInvalidMove, onItemMove, onItemsChange, onLoadMore, onRenameItem, onSelect, onSelectionChange, selectedKeys, selectionHydrationMode, selectionMode, spritemap, showExpanderOnHover, ...otherProps }: ITreeViewProps<T>): React.JSX.Element;
export declare namespace TreeView {
    var Group: typeof import("./TreeViewGroup").Group;
    var Item: React.ForwardRefExoticComponent<import("./TreeViewItem").ITreeViewItemProps & React.RefAttributes<HTMLDivElement>>;
    var ItemStack: typeof import("./TreeViewItem").ItemStack;
}
export {};
