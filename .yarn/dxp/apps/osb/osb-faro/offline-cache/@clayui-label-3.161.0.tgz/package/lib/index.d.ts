/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare const ItemAfter: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
export declare const ItemBefore: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
export declare const ItemExpand: React.ForwardRefExoticComponent<React.BaseHTMLAttributes<HTMLAnchorElement | HTMLSpanElement> & React.RefAttributes<HTMLAnchorElement | HTMLSpanElement>>;
interface IBaseProps extends React.BaseHTMLAttributes<HTMLSpanElement> {
    /**
     * Flag to indicate if `label-dismissible` class should be applied.
     */
    dismissible?: boolean;
    /**
     * Determines the style of the label.
     */
    displayType?: 'secondary' | 'info' | 'warning' | 'danger' | 'success' | 'unstyled';
    /**
     * Flag to indicate if the label should be of the `large` variant.
     */
    large?: boolean;
}
interface IProps extends IBaseProps {
    /**
     * HTML properties that are applied to the 'x' button.
     */
    closeButtonProps?: React.ButtonHTMLAttributes<HTMLButtonElement> & {
        ref?: (instance: HTMLButtonElement | null) => void;
    };
    /**
     * Pros to add to the inner label item
     */
    innerElementProps?: React.ComponentProps<typeof ItemExpand>;
    /**
     * Path to the location of the spritemap resource used for Icon.
     */
    spritemap?: string;
    /**
     * Flag to indicate if component should include the close button
     */
    withClose?: boolean;
}
declare const Label: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLAnchorElement | HTMLSpanElement>> & {
    ItemAfter: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
    ItemBefore: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLSpanElement> & React.RefAttributes<HTMLSpanElement>>;
    ItemExpand: React.ForwardRefExoticComponent<React.BaseHTMLAttributes<HTMLAnchorElement | HTMLSpanElement> & React.RefAttributes<HTMLAnchorElement | HTMLSpanElement>>;
};
export default Label;
