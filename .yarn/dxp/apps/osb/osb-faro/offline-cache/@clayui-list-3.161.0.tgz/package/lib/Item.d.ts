/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLLIElement> {
    /**
     * Flag to indicate if the `list-group-item-action` class should be applied.
     */
    action?: boolean;
    /**
     * Flag to indicate if item is active or selected.
     */
    active?: boolean;
    /**
     * Flag to indicate if item should be displayed with a disabled style.
     */
    disabled?: boolean;
    /**
     * Flag to indicate if item should be `display: flex`.
     */
    flex?: boolean;
    /**
     * Flag to indicate if item is used as a header.
     */
    header?: boolean;
}
declare const Item: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLLIElement>>;
export default Item;
