/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IGroup extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Indicates Form Group should be a small variant.
     */
    small?: boolean;
}
interface IFeedbackIndicatorProps extends React.HTMLAttributes<HTMLSpanElement> {
    /**
     * Path to the location of the spritemap resource.
     */
    spritemap?: string;
    /**
     * Name of icon symbol
     */
    symbol: string;
}
declare const _default: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLFormElement> & React.RefAttributes<HTMLFormElement>> & {
    BlockquoteText: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
    FeedbackGroup: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
    FeedbackIndicator: React.ForwardRefExoticComponent<IFeedbackIndicatorProps & React.RefAttributes<HTMLDivElement>>;
    FeedbackItem: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
    Group: React.ForwardRefExoticComponent<IGroup & React.RefAttributes<HTMLDivElement>>;
    HelpText: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
    Text: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
};
export default _default;
