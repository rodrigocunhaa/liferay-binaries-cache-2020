/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { AlignPoints } from '@clayui/shared';
import React from 'react';
declare type Props = {
    'alignmentPosition'?: number | AlignPoints;
    'aria-label'?: string;
    'disabled'?: boolean;
    'disabledPages'?: Array<number>;
    'hrefConstructor'?: (page?: number) => string;
    'items'?: Array<number>;
    'onPageChange'?: (page?: number) => void;
    'title'?: string;
};
export declare function Ellipsis({ alignmentPosition: _alignmentPosition, disabled, disabledPages, hrefConstructor, items, onPageChange, ...otherProps }: Props): React.JSX.Element;
export {};
