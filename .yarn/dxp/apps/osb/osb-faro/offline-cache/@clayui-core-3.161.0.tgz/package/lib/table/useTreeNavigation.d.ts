/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
declare type Props<T> = {
    /**
     * Flag to disable navigation in a tree.
     */
    disabled?: boolean;
    /**
     * Flag to indicate the ARIA role of a tree element.
     */
    locator: {
        cell: string;
        row: string;
    };
    /**
     * Reference of the parent element of the focusable elements.
     */
    ref: React.RefObject<T>;
};
export declare function useTreeNavigation<T extends HTMLElement>({ disabled, locator, ref, }: Props<T>): {
    navigationProps: {
        onKeyDownCapture: (event: React.KeyboardEvent<T>) => void;
    };
};
export {};
