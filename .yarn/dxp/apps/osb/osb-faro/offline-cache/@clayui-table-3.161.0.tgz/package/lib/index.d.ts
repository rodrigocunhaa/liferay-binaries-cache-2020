/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type ResposiveSizeType = 'lg' | 'md' | 'sm' | 'xl';
declare type VerticalAlignmentType = 'bottom' | 'middle' | 'top';
export interface IProps extends React.HTMLAttributes<HTMLTableElement> {
    /**
     * This property vertically align the contents
     * inside the table body according a given position.
     */
    bodyVerticalAlignment?: VerticalAlignmentType;
    /**
     * Applies a Bordered style on Table's columns.
     */
    borderedColumns?: boolean;
    /**
     * Removes the default border and rounded corners from table.
     */
    borderless?: boolean;
    /**
     * This property vertically align the contents
     * inside the table header according a given position.
     */
    headVerticalAlignment?: VerticalAlignmentType;
    /**
     * This property keeps all the headings on one line.
     */
    headingNoWrap?: boolean;
    /**
     * Applies a Hover style on Table.
     */
    hover?: boolean;
    /**
     * This property enables keeping everything on one line.
     */
    noWrap?: boolean;
    /**
     * Turns the table responsive.
     */
    responsive?: boolean;
    /**
     * Defines the responsive sizing.
     */
    responsiveSize?: ResposiveSizeType;
    /**
     * Applies a Striped style on Table.
     */
    striped?: boolean;
    /**
     * This property vertically align the contents
     * inside the table according a given position.
     */
    tableVerticalAlignment?: VerticalAlignmentType;
}
declare const _default: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLDivElement>> & {
    Body: React.ForwardRefExoticComponent<React.TableHTMLAttributes<HTMLTableSectionElement> & React.RefAttributes<HTMLTableSectionElement>>;
    Cell: React.ForwardRefExoticComponent<import("./Cell").ICellProps & React.RefAttributes<HTMLTableDataCellElement | HTMLTableHeaderCellElement>>;
    Head: React.ForwardRefExoticComponent<React.TableHTMLAttributes<HTMLTableSectionElement> & React.RefAttributes<HTMLTableSectionElement>>;
    Row: React.ForwardRefExoticComponent<import("./Row").IRowProps & React.RefAttributes<HTMLTableRowElement>>;
};
export default _default;
