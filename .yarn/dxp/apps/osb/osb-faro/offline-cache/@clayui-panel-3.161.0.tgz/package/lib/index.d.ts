/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Flag to indicate that Panel is collapsable.
     */
    collapsable?: boolean;
    /**
     * Adds classes to the collapse element. Only when `collapsable` is true.
     */
    collapseClassNames?: string;
    /**
     * Adds classes to the collapse header element. Only when `collapsable` is true.
     */
    collapseHeaderClassNames?: string;
    /**
     * Flag to indicate the initial value of expanded (uncontrolled).
     */
    defaultExpanded?: boolean;
    /**
     * Content to display in Panel Title.
     */
    displayTitle?: React.ReactNode;
    /**
     * Flag to indicate the visual variation of the Panel.
     */
    displayType?: 'block' | 'default' | 'secondary' | 'unstyled';
    /**
     * Determines if menu is expanded or not (controlled).
     */
    expanded?: boolean;
    /**
     * Callback for when dropdown changes its active state (controlled).
     */
    onExpandedChange?: InternalDispatch<boolean>;
    /**
     * Flag to toggle collapse icon visibility when `collapsable` is true.
     */
    showCollapseIcon?: boolean;
    /**
     * Flag to indicate the visual variation of the Panel.
     */
    size?: 'lg' | 'sm';
    /**
     * Path to spritemap for clay icons
     */
    spritemap?: string;
}
declare function Panel({ children, className, collapsable, collapseClassNames, collapseHeaderClassNames, defaultExpanded, displayTitle, displayType, expanded, onExpandedChange, showCollapseIcon, size, spritemap, ...otherProps }: IProps): React.JSX.Element;
declare namespace Panel {
    var Body: typeof import("./Body").Body;
    var Group: typeof import("./Group").Group;
    var Footer: typeof import("./Footer").Footer;
    var Header: typeof import("./Header").Header;
    var Title: typeof import("./Title").Title;
}
export default Panel;
