/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { ClayDropDownWithItems } from '@clayui/drop-down';
import React from 'react';
export interface IListItem {
    /**
     * Description of item.
     */
    description?: string;
    /**
     * Props to add to the dropdown trigger element
     */
    dropDownTriggerProps?: React.HTMLAttributes<HTMLButtonElement>;
    /**
     * List of actions to include in dropdown.
     */
    dropdownActions?: React.ComponentProps<typeof ClayDropDownWithItems>['items'];
    /**
     * Value to display if item is a header.
     */
    header?: string;
    /**
     * Click through url for item.
     */
    href?: string;
    /**
     * List of items to display below header.
     */
    items?: Array<IListItem>;
    /**
     * List of labels to display for item.
     */
    labels?: Array<any>;
    /**
     * List of actions to display as hoverable actions.
     */
    quickActions?: Array<any>;
    /**
     * Name of icon symbol.
     */
    symbol?: string;
    /**
     * Title of item.
     */
    title?: string;
    /**
     * Optional properties that an item can include for callback purposes.
     */
    [s: string]: any;
}
interface IBooleanMap {
    [s: string]: boolean;
}
interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Property of item that makes it unique from other items.
     * Defaults to 'id'.
     */
    itemIdentifier?: string | 'id';
    /**
     * Items to show in list.
     */
    items?: Array<IListItem>;
    /**
     * Callback for when selected items change.
     */
    onSelectedItemsChange?: (map: IBooleanMap) => void;
    /**
     * Map of items that are currently selected.
     */
    selectedItemsMap?: IBooleanMap;
    /**
     * Path to spritemap for icon symbol.
     */
    spritemap?: string;
}
export declare function ListWithItems({ className, itemIdentifier, items, selectedItemsMap, onSelectedItemsChange, spritemap, ...otherProps }: IProps): React.JSX.Element;
export {};
