/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
/**
 * A hook that takes care of controlling click, keyup and keydown events
 * respectively close the modal after a click on the overlay, close the
 * modal by pressing the ESC key and control the focus within the Modal.
 */
declare function useUserInteractions(modalElementRef: React.MutableRefObject<any>, modalBodyElementRef: React.MutableRefObject<any>, onClick: () => void, show: boolean, content: boolean): void;
export { useUserInteractions };
