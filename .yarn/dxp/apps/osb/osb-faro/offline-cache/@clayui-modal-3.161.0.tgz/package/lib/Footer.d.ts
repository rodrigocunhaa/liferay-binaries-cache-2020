/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IFooterProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Sets the elements that are positioned `first following
     * the LTR direction on the footer.
     */
    first?: React.ReactElement;
    /**
     * Sets the elements that are positioned `last` following
     * the LTR direction on the footer.
     */
    last?: React.ReactElement;
    /**
     * Sets the elements that are positioned in the middle
     * of the footer.
     */
    middle?: React.ReactElement;
}
declare function Footer({ className, first, last, middle, ...otherProps }: IFooterProps): React.JSX.Element;
export default Footer;
