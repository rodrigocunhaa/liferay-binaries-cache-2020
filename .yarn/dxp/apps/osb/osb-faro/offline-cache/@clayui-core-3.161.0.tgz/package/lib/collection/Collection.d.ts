/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { CollectionState, ICollectionProps, Props } from './types';
interface IProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
    /**
     * Component to render.
     */
    as?: 'div' | React.ComponentType | React.ForwardRefExoticComponent<any>;
    /**
     * Suspense collection that was initialized before the component rendered.
     */
    collection?: CollectionState;
    /**
     * Flag to estimate the default height of a list item in pixels.
     */
    estimateSize?: number;
    /**
     * Flag if a request is in progress.
     */
    isLoading?: boolean;
    /**
     * Defines the method for enable infinite scroll and loading more data into
     * the list.
     */
    onLoadMore?: () => Promise<any> | null;
    /**
     * Add the reference of the parent element that will be used to define the
     * scroll and get the height of the element for virtualization of the
     * collection.
     */
    parentRef: React.RefObject<HTMLElement>;
}
export declare function Collection<T extends Record<string, any> | string | number, P = unknown, K = unknown>({ as, children, collection, connectNested, estimateSize, exclude, filter, filterKey, isLoading, itemContainer, itemIdKey, items, onLoadMore, parentKey, parentRef, passthroughKey, publicApi, suppressTextValueWarning, virtualize, ...otherProps }: Partial<ICollectionProps<T, P>> & Props<P, K> & Partial<IProps>): React.JSX.Element;
export {};
