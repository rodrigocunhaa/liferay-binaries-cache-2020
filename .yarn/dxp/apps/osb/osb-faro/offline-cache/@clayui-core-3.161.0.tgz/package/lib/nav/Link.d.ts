/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IPropsLink extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
    /**
     * Flag to indicate if `active` class should be applied.
     */
    active?: boolean;
    /**
     * Flag to indicate if `collapsed` class should be applied.
     */
    collapsed?: boolean;
    /**
     * Flag to indicate if `disabled` class should be applied.
     */
    disabled?: boolean;
    /**
     * Flag to indicate if icon should be shown.
     */
    showIcon?: boolean;
    /**
     * Path to the spritemap that Icon should use when referencing symbols.
     */
    spritemap?: string;
}
declare const Link: React.ForwardRefExoticComponent<IPropsLink & React.RefAttributes<HTMLAnchorElement | HTMLButtonElement | HTMLDivElement>>;
export { Link };
