/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { IPortalBaseProps } from '@clayui/shared';
import React from 'react';
declare type TContentRenderer = (props: {
    targetNode?: HTMLElement | null;
    title: string;
}) => React.ReactElement | React.ReactNode;
declare type Props = {
    /**
     * Flag to indicate if tooltip should automatically align based on the window
     */
    autoAlign?: boolean;
    children?: React.ReactElement;
    /**
     * Props to add to the `<ClayPortal/>`.
     */
    containerProps?: IPortalBaseProps;
    /**
     * Custom function for rendering the contents of the tooltip
     */
    contentRenderer?: TContentRenderer;
    /**
     * Delay in miliseconds before showing tooltip
     */
    delay?: number;
    /**
     * CSS selector to scope provider to. All titles within this scope will be
     * rendered in the tooltip. Titles outside of this scope will be styled
     * as with the default browser.
     */
    scope?: string;
};
export declare function ClayTooltipProvider({ autoAlign, children, containerProps, contentRenderer, delay, scope, }: Props): React.JSX.Element;
export {};
