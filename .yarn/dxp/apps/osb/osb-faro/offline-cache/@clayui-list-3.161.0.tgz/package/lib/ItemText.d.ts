/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLParagraphElement> {
    /**
     * Flag to indicate if content should be styled as subtext.
     */
    subtext?: boolean;
}
declare const ItemText: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLParagraphElement>>;
export default ItemText;
