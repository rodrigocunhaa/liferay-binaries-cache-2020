/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { AlignPoints, InternalDispatch } from '@clayui/shared';
import React from 'react';
import { PaginationBar } from './PaginationBar';
interface IDelta {
    /**
     * Path or URL to be used for some SPA focused use cases.
     */
    href?: string;
    /**
     * Label of the delta
     */
    label: number;
}
interface IProps extends React.ComponentProps<typeof PaginationBar> {
    /**
     * Sets the currently active page (controlled).
     */
    active?: number;
    /**
     * The value of delta that is currently selected
     */
    activeDelta?: number;
    /**
     * Initialize the page that is currently active. The first page is `1`.
     * @deprecated since v3.52.0 - use `active` instead.
     */
    activePage?: number;
    /**
     * Sets the default DropDown position of the component. The component
     * receives the Align constant values from the `@clayui/drop-down` package.
     */
    alignmentPosition?: number | AlignPoints;
    /**
     * Sets the default active page (uncontrolled).
     */
    defaultActive?: number;
    /**
     * Possible values of items per page.
     */
    deltas?: Array<IDelta>;
    /**
     * Flag to disable ellipsis button
     */
    disableEllipsis?: boolean;
    /**
     * The page numbers that should be disabled. For example, `[2,5,6]`.
     */
    disabledPages?: Array<number>;
    /**
     * The number of pages to show on each side of the active page before
     * using an ellipsis dropdown.
     */
    ellipsisBuffer?: number;
    /**
     * Properties to pass to the ellipsis trigger.
     */
    ellipsisProps?: Object;
    /**
     * Function used to create the href provided for each page link.
     */
    hrefConstructor?: (page?: number) => string;
    /**
     * Labels for changing some texts inside the component.
     * Use this property for i18n.
     */
    labels?: {
        itemsPerPagePickerAriaLabel?: string;
        paginationResults: string;
        perPageItems: string;
        selectPerPageItems: string;
    };
    /**
     * Callback called when the state of the active page changes (controlled).
     * This is only used if an href is not provided.
     */
    onActiveChange?: InternalDispatch<number>;
    /**
     * Callback for when the number of elements per page changes. This is only used if
     * an href is not provided.
     */
    onDeltaChange?: (page: number) => void;
    /**
     * Callback for when the active page changes. This is only used if
     * an href is not provided.
     * @deprecated since v3.52.0 - use `onActiveChange` instead.
     */
    onPageChange?: (page: number) => void;
    /**
     * Flags indicating if the DropDown should be rendered.
     */
    showDeltasDropDown?: boolean;
    /**
     * Path to spritemap from clay-css.
     */
    spritemap?: string;
    /**
     * The total number of items in the pagination list.
     */
    totalItems: number;
}
export declare function ClayPaginationBarWithBasicItems({ active, activeDelta, activePage, alignmentPosition, defaultActive, deltas, disabledPages, disableEllipsis, ellipsisBuffer, ellipsisProps, hrefConstructor, labels, onActiveChange, onDeltaChange, onPageChange, showDeltasDropDown, spritemap, totalItems, ...otherProps }: IProps): React.JSX.Element;
export {};
