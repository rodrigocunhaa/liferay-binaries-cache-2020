/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
declare type Props = {
    activeDescendant: React.Key;
    ariaControls: string;
    getOptions: () => Array<HTMLElement>;
    onActiveChange: InternalDispatch<boolean>;
    onChange: InternalDispatch<string>;
    onKeyDown: InternalDispatch<React.KeyboardEvent<HTMLElement>>;
    onMoveFocus: (key: 'PageUp' | 'PageDown', position: number, list: Array<HTMLElement> | Array<React.Key>) => void;
    onPress: () => void;
    placeholder: string;
    triggerRef: React.RefObject<HTMLButtonElement | null>;
    value: string;
};
export declare const Search: React.ForwardRefExoticComponent<Props & React.RefAttributes<HTMLInputElement>>;
export {};
