/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
    /**
     * Message the user will see describing what they can do when on this screen
     */
    description?: string;
    /**
     * HTMLImage element attributes to add to the image within the component
     */
    imgProps?: React.ImgHTMLAttributes<HTMLImageElement>;
    /**
     * HTMLImage element attributes to add to the reduced motion image within the component
     */
    imgPropsReducedMotion?: React.ImgHTMLAttributes<HTMLImageElement>;
    /**
     * Source of the image to signify the state
     */
    imgSrc?: string;
    /**
     * Source of the image to show when `.c-prefers-reduced-motion` is active
     */
    imgSrcReducedMotion?: string | null;
    /**
     * Indicates empty state should be a small variant.
     */
    small?: boolean;
    /**
     * Title of the message highlighting the description
     */
    title?: string | null;
}
declare function EmptyState({ children, className, description, imgProps, imgPropsReducedMotion, imgSrc, imgSrcReducedMotion, small, title, ...otherProps }: IProps): React.JSX.Element;
export default EmptyState;
