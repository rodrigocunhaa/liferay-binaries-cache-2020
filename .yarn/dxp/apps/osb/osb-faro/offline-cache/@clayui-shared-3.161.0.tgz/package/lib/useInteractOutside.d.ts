/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    isDisabled?: boolean;
    onInteract?: (event: Event) => void;
    onInteractStart?: (event: Event) => void;
    ref: React.RefObject<HTMLElement>;
    triggerRef: React.RefObject<HTMLElement>;
};
/**
 * Code ported with some minor modifications
 * https://github.com/adobe/react-spectrum/blob/810579b671791f1593108f62cdc1893de3a220e3/packages/%40react-aria/interactions/src/useInteractOutside.ts
 */
export declare function useInteractOutside({ isDisabled, onInteract, onInteractStart, ref, triggerRef, }: Props): void;
export {};
