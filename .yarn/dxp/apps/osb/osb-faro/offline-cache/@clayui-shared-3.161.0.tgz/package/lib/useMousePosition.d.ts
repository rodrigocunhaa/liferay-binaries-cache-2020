/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
declare type MousePosition = [number, number];
/**
 * Hook to get the current mouse position
 */ export declare function useMousePosition(delay?: number): MousePosition;
export {};
