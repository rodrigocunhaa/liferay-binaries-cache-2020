/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { Autocomplete } from './Autocomplete';
import Item from './Item';
import LegacyAutocomplete from './LegacyAutocomplete';
export { Autocomplete, Item };
export default LegacyAutocomplete;
