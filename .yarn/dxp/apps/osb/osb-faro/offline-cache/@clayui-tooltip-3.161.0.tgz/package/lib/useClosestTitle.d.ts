/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    forceHide: () => void;
    onClick: () => void;
    onHide: () => void;
    tooltipRef: React.MutableRefObject<HTMLElement | null>;
};
export declare function useClosestTitle(props: Props): {
    forceHide: () => void;
    getProps: (event: React.MouseEvent<HTMLElement, MouseEvent>, hideBrowserTitle: boolean) => {
        align: string | null;
        delay: string | null;
        floating: boolean;
        setAsHTML: boolean;
        title: string;
    } | undefined;
    onHide: (event?: any) => null | undefined;
    target: React.MutableRefObject<HTMLElement | null>;
    titleNode: React.MutableRefObject<HTMLElement | null>;
};
export {};
