/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { Key } from 'react';
/**
 * Cursors are the reference to the unique id of the items in the tree
 * referring to their parent. Cursor creates the safe address of an item
 * in the tree for immutability operations.
 */
export declare type Cursor = Array<React.Key>;
export declare type LayoutInfo = {
    children: Set<Key>;
    cursor: Cursor;
    icon: string | undefined;
    /**
     * Lazy Child means that the current Node has children but they were not
     * created because they are not visible in the DOM.
     */
    lazyChild: boolean;
    loc: Array<number>;
    name: string;
    parentKey?: Key;
};
export declare type Layout = {
    createPartialLayoutItem: (key: Key, lazy: boolean, loc: Array<number>, name: string, icon: string | undefined, cursor: Cursor, parentKey?: Key) => () => void;
    layoutKeys: React.MutableRefObject<Map<Key, LayoutInfo>>;
    patchItem: (key: Key, cursor: Cursor, loc: Array<number>) => void;
};
export declare function useLayout(): Layout;
