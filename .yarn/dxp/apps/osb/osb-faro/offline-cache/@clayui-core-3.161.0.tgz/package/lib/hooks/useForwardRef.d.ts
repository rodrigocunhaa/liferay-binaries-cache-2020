/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { Ref } from 'react';
export declare function useForwardRef<T = HTMLElement>(outRef: Ref<T>): import("react").RefObject<T>;
