/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
export declare type Interaction = 'keyboard' | 'pointer' | 'virtual';
declare function isFocusVisible(): boolean;
declare function getInteraction(): Interaction;
/**
 * Detects what type of interaction the user is doing with the page, using the
 * keyboard, pointer or using screen reader. This works like a singleton even
 * if it is declared more than once.
 *
 * This is inspired by the implementation:
 * https://github.com/adobe/react-spectrum/blob/d10f20a3f4ca7ffa807fcaceb944274da825a7b9/packages/%40react-aria/interactions/src/useFocusVisible.ts
 */
export declare function useInteractionFocus(): {
    getInteraction: typeof getInteraction;
    isFocusVisible: typeof isFocusVisible;
};
export declare function useFocusVisible(): boolean;
export {};
