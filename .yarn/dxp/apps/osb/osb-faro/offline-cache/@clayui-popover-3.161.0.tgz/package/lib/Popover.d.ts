/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { IPortalBaseProps, InternalDispatch } from '@clayui/shared';
import React from 'react';
export declare const ALIGN_POSITIONS: readonly ["top", "top-left", "top-right", "bottom", "bottom-left", "bottom-right", "left", "left-top", "left-bottom", "right", "right-top", "right-bottom"];
declare const ALIGNMENTS_MAP: {
    readonly bottom: readonly ["tc", "bc"];
    readonly 'bottom-left': readonly ["tl", "bl"];
    readonly 'bottom-right': readonly ["tr", "br"];
    readonly left: readonly ["cr", "cl"];
    readonly 'left-bottom': readonly ["br", "bl"];
    readonly 'left-top': readonly ["tr", "tl"];
    readonly right: readonly ["cl", "cr"];
    readonly 'right-bottom': readonly ["bl", "br"];
    readonly 'right-top': readonly ["tl", "tr"];
    readonly top: readonly ["bc", "tc"];
    readonly 'top-left': readonly ["bl", "tl"];
    readonly 'top-right': readonly ["br", "tr"];
};
declare type Point = (typeof ALIGNMENTS_MAP)[keyof typeof ALIGNMENTS_MAP];
interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Position in which the tooltip will be aligned to the element.
     */
    alignPosition?: (typeof ALIGN_POSITIONS)[number];
    /**
     * Flag to indicate if the popover should be closed when
     * clicking outside, only works if used with trigger
     */
    closeOnClickOutside?: boolean;
    /**
     * Props to add to the `<ClayPortal/>`.
     */
    containerProps?: IPortalBaseProps;
    /**
     * Sets the default value of show (uncontrolled).
     */
    defaultShow?: boolean;
    /**
     * Flag to indicate if container should not be scrollable
     */
    disableScroll?: boolean;
    /**
     * Appends the type to `popover-`
     */
    displayType?: string;
    /**
     * Content to display in the header of the popover.
     */
    header?: React.ReactNode;
    /**
     * Callback for setting the offset of the popover from the trigger.
     */
    onOffset?: (points: Point) => [number, number];
    /**
     * Callback for when the `show` prop changes (controlled).
     */
    onShowChange?: InternalDispatch<boolean>;
    /**
     * Flag to indicate if tooltip is displayed (controlled).
     */
    show?: boolean;
    /**
     * Sets the size of the popover.
     */
    size?: 'lg';
    /**
     * React element that the popover will align to when clicked.
     */
    trigger?: React.ReactElement & Omit<React.RefAttributes<HTMLButtonElement>, 'key'>;
}
export declare const Popover: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLDivElement>>;
export {};
