/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { AnnouncerAPI } from '@clayui/core';
import { CollectionState } from '@clayui/core/src/collection/types';
import React, { RefObject } from 'react';
import { AutocompleteMessages } from './Autocomplete';
interface IProps {
    /**
     * Flag to indicate if the autocomplete is active (i.e., the menu is open)
     */
    active: boolean;
    /**
     * Reference to the announcer API.
     */
    announcer: RefObject<AnnouncerAPI>;
    /**
     * The collection state of the autocomplete items.
     */
    collection: CollectionState;
    /**
     * Loading state of the autocomplete.
     */
    loadingState?: number;
    /**
     * Localized messages for the autocomplete.
     */
    messages: Required<AutocompleteMessages>;
    /**
     * Callback function to load more items.
     */
    onLoadMore?: () => Promise<any> | null;
}
export declare function useInfiniteScroll({ active, announcer, collection, loadingState, messages, onLoadMore, }: IProps): () => React.JSX.Element | null;
export {};
