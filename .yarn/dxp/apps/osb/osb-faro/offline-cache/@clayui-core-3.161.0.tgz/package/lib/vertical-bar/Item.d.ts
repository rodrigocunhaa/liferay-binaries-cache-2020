/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    /**
     * Item content.
     */
    children: React.ReactElement;
    /**
     * Sets the divider between items.
     */
    divider?: boolean;
    /**
     * Flag to expand the item, the next one will be aligned at the bottom of
     * the bar.
     */
    expand?: boolean;
    /**
     * Internal property.
     * @ignore
     */
    index?: number;
    /**
     * Internal property.
     * @ignore
     */
    keyValue?: React.Key | null;
    /**
     * @ignore
     */
    style?: React.StyleHTMLAttributes<HTMLLIElement>;
};
export declare const Item: React.ForwardRefExoticComponent<Props & React.RefAttributes<HTMLLIElement>>;
export {};
