/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export interface IProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
    /**
     * Initial value of the input (uncontrolled).
     */
    defaultValue?: string;
    /**
     * Props to add to form element
     */
    formProps?: React.HTMLAttributes<HTMLFormElement>;
    /**
     * Callback for when input value changes (controlled).
     */
    onChange?: InternalDispatch<string>;
    /**
     * Path to the location of the spritemap resource.
     */
    spritemap?: string;
    /**
     * Props to add to the button component.
     */
    submitProps?: React.HTMLAttributes<HTMLButtonElement>;
    /**
     * Current value of the input (controlled).
     */
    value?: string;
}
declare function Search({ className, defaultValue, formProps, onChange, spritemap, submitProps, value: valueProp, ...otherProps }: IProps): React.JSX.Element;
export default Search;
