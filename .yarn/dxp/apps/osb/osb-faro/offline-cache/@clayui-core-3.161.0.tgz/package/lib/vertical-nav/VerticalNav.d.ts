/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import { Item } from './Item';
import { Trigger } from './Trigger';
import type { ChildrenFunction } from '../collection';
declare type Props<T extends Record<string, any> | string> = {
    /**
     * Flag to indicate the navigation behavior in the menu.
     *
     * - manual - it will just move the focus and menu activation is done just
     * by pressing space or enter.
     * - automatic - moves the focus to the menuitem and activates the menu.
     */
    'activation'?: 'manual' | 'automatic';
    /**
     * Flag to define which item has the active state/current page.
     */
    'active'?: React.Key;
    /**
     * Flag to define aria-label.
     */
    'aria-label'?: string;
    /**
     * The component contents.
     */
    'children'?: React.ReactNode | ChildrenFunction<T, null>;
    /**
     * Flag to determine whether the collapse wrapper should be rendered or not
     */
    'collapse'?: boolean;
    /**
     * Flag to activate the Decorator variation.
     */
    'decorated'?: boolean;
    /**
     * Property to set the initial value of `expandedKeys` (uncontrolled).
     */
    'defaultExpandedKeys'?: Set<React.Key>;
    /**
     * Determines the Vertical Nav variant to use.
     * @default transparent
     */
    'displayType'?: 'transparent' | 'primary';
    /**
     * The currently expanded keys in the collection (controlled).
     */
    'expandedKeys'?: Set<React.Key>;
    /**
     * Flag to define if the item represents the current page. Disable this
     * attribute only if there are multiple navigations on the page.
     */
    'itemAriaCurrent'?: boolean;
    /**
     * Property to inform the dynamic data of the tree.
     */
    'items'?: Array<T>;
    /**
     * Flag to indicate if `menubar-vertical-expand-lg` class is applied.
     * @deprecated Use "size" to determine the desired breakpoint
     */
    'large'?: boolean;
    /**
     * Flag to indicate if `nav-nested-margins` class should be applied.
     * It uses margin instead of padding to indent each nested navigation.
     */
    'nestMargins'?: boolean;
    /**
     * A callback that is called when items are expanded or collapsed
     * (controlled).
     */
    'onExpandedChange'?: InternalDispatch<Set<React.Key>>;
    /**
     * Defines the size class to use with the menu
     */
    'size'?: 'lg' | 'md';
    /**
     * Path to the spritemap that Icon should use when referencing symbols.
     */
    'spritemap'?: string;
    /**
     * Flag to indicate if `nav-stacked` class should be applied. It doesn't
     * indent nested navigation.
     */
    'stacked'?: boolean;
    /**
     * Custom component that will be displayed on mobile resolutions that
     * toggles the visibility of the navigation.
     */
    'trigger'?: typeof Trigger;
    /**
     * Label of the button that appears on smaller resolutions to open the
     * vertical navigation.
     */
    'triggerLabel'?: string;
};
declare function VerticalNav<T extends Record<string, any> | string>(props: Props<T>): JSX.Element & {
    Item: typeof Item;
    Trigger: typeof Trigger;
};
declare namespace VerticalNav {
    var Item: typeof import("./Item").Item;
    var Trigger: typeof import("./Trigger").Trigger;
}
export { VerticalNav };
