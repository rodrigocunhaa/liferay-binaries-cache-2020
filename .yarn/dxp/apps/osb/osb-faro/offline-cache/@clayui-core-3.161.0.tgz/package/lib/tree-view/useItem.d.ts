/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { Value } from './DragAndDrop';
declare type Props = {
    children: React.ReactNode;
    value: Omit<Value, 'indexes'> & {
        index: number;
    };
};
export declare function ItemContextProvider({ children, value }: Props): React.JSX.Element;
export declare function useItem(): Value;
export {};
