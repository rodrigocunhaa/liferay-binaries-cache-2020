/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { ClayButtonWithIcon } from '@clayui/button';
import React from 'react';
interface IProps<T> extends React.HTMLAttributes<HTMLLIElement> {
    /**
     * Flag to indicate if item is active.
     * @deprecated since version 3.94.0 - use the `active` property on the
     * root component.
     */
    active?: boolean;
    /**
     * The contents of the component.
     */
    children?: React.ReactNode;
    /**
     * Link href for item.
     */
    href?: string;
    /**
     * @ignore
     */
    index?: number;
    /**
     * @ignore
     * @deprecated
     */
    initialExpanded?: boolean;
    /**
     * Property to inform the dynamic data of the tree.
     */
    items?: Array<T>;
    /**
     * @ignore
     */
    keyValue?: React.Key;
    /**
     * Properties to pass to the menubar action
     */
    menubarAction?: React.ComponentProps<typeof ClayButtonWithIcon>;
    /**
     * @ignore
     */
    textValue?: string;
}
export declare function Item<T extends Record<string, any>>({ active: depreactedActive, children, href, index: _, initialExpanded, items, keyValue, menubarAction, onClick, textValue: _textValue, ...otherProps }: IProps<T>): React.JSX.Element;
export declare namespace Item {
    var displayName: string;
}
export {};
