/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare const Item: React.ForwardRefExoticComponent<{
    /**
     * @ignore
     */
    'data-index'?: number | undefined;
    /**
     * Flag that indicates if item is disabled.
     */
    disabled?: boolean | undefined;
    /**
     * Path for item to link to.
     */
    href?: string | undefined;
    /**
     * @ignore
     */
    keyValue?: React.Key | undefined;
    /**
     * Item value for accessibility.
     */
    textValue?: string | undefined;
} & React.HTMLAttributes<HTMLAnchorElement | HTMLButtonElement | HTMLSpanElement> & React.RefAttributes<HTMLLIElement>>;
