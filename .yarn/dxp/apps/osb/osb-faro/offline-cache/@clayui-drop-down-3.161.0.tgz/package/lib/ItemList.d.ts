/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { ICollectionProps } from '@clayui/core';
export interface IProps<T> extends Omit<ICollectionProps<T, unknown>, 'virtualize'>, Omit<React.HTMLAttributes<HTMLUListElement>, 'children'> {
}
declare const ItemList: React.ForwardRefExoticComponent<IProps<unknown> & React.RefAttributes<HTMLUListElement>>;
export default ItemList;
