/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
declare type Props = {
    /**
     * Flag to position the component using absolute rather than a
     * fixed position.
     */
    absolute?: boolean;
    /**
     * Flag to indicate the navigation behavior in the tab.
     *
     * - manual - it will just move the focus and tab activation is done just
     * by pressing space or enter.
     * - automatic - moves the focus to the tab and activates the tab.
     */
    activation?: 'manual' | 'automatic';
    /**
     * Sets the current active panel (controlled).
     */
    active?: React.Key | null;
    /**
     * The VerticalBar content.
     */
    children: React.ReactNode;
    /**
     * Sets the CSS className for the component.
     */
    className?: string;
    /**
     * Sets the default active panel (uncontrolled).
     */
    defaultActive?: React.Key | null;
    /**
     * Panel width initial value (uncontrolled).
     */
    defaultPanelWidth?: number;
    /**
     * Callback is called when the active state changes (controlled).
     */
    onActiveChange?: InternalDispatch<React.Key | null>;
    /**
     * Callback called when panel width changes (controlled).
     */
    onPanelWidthChange?: InternalDispatch<number>;
    /**
     * Sets a custom width on the sidebar panel (controlled).
     */
    panelWidth?: number;
    /**
     * Sets a maximum width on the sidebar panel.
     */
    panelWidthMax?: number;
    /**
     * Sets a minimum width on the sidebar panel.
     */
    panelWidthMin?: number;
    /**
     * Sets the position of the vertical bar.
     */
    position?: 'left' | 'right';
    /**
     * Flag to enable resizing the sidebar panel.
     */
    resize?: boolean;
};
export declare function VerticalBar({ absolute, activation, active, children, className, defaultActive, defaultPanelWidth, onActiveChange, onPanelWidthChange, panelWidth: externalPanelWidth, panelWidthMax, panelWidthMin, position, resize, }: Props): React.JSX.Element;
export declare namespace VerticalBar {
    var Bar: typeof import("./Bar").Bar;
    var Content: typeof import("./Content").Content;
    var Item: React.ForwardRefExoticComponent<{
        children: React.ReactElement<any, string | React.JSXElementConstructor<any>>;
        divider?: boolean | undefined;
        expand?: boolean | undefined;
        index?: number | undefined;
        keyValue?: React.Key | null | undefined;
        style?: React.StyleHTMLAttributes<HTMLLIElement> | undefined;
    } & React.RefAttributes<HTMLLIElement>>;
    var Panel: typeof import("./Panel").Panel;
}
export {};
