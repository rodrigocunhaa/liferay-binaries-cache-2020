/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import ClayLink from '@clayui/link';
import React from 'react';
export interface IPaginationItemProps extends React.HTMLAttributes<HTMLAnchorElement | HTMLDivElement> {
    active?: boolean;
    as?: 'div' | typeof ClayLink;
    disabled?: boolean;
    href?: string;
}
export declare function Item({ as: As, active, children, disabled, href, ...otherProps }: IPaginationItemProps): React.JSX.Element;
