/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLLIElement> {
    /**
     * Determines the active state of an dropdown list item.
     */
    active?: boolean;
    /**
     * Children elements received from ClayNavigationBar.Item component.
     */
    children: React.ReactElement;
}
export declare function Item({ active, children, className, ...otherProps }: IProps): React.JSX.Element;
