/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    /**
     * Children content to render a content.
     */
    children: React.ReactNode;
    /**
     * Sets the CSS className for the component.
     */
    className?: string;
    /**
     * Messages for the Side Panel Header.
     */
    messages?: Messages;
    /**
     * Function to execute when the back button is pressed.
     */
    onBack?: () => void;
    /**
     * Property to make the Header sticky. Absolutely positioned SidePanel's
     * should have the `sidebar-header` `top` CSS property adjusted to account
     * for any fixed or sticky navigation bars on the page.
     */
    sticky?: boolean;
};
export declare type Messages = {
    backAriaLabel?: string;
    closeAriaLabel?: string;
};
export declare function Header({ children, className, messages, sticky, onBack, }: Props): React.JSX.Element;
export {};
