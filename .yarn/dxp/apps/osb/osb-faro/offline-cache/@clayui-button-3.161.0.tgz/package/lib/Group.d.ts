/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    /**
     * Flag to indicate the spacing between the buttons.
     */
    spaced?: boolean;
    /**
     * Flag to indicate if buttons are stacked vertically.
     */
    vertical?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;
declare function Group({ children, className, role, spaced, vertical, ...otherProps }: Props): React.JSX.Element;
declare namespace Group {
    var displayName: string;
}
export default Group;
