/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
/**
 * Utility function for substituting variables into language keys.
 */ export declare function sub(langKey: string, args: Array<React.ReactText>): string;
