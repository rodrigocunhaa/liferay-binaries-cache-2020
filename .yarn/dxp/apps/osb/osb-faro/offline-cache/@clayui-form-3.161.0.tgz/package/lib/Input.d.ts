/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IGroupItemProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Flag to indicate if `input-group-append` class should
     * be applied
     */
    append?: boolean;
    /**
     * Flag to indicate if `input-group-prepend` class should
     * be applied
     */
    prepend?: boolean;
    /**
     * Flag to indicate if `input-group-item-shrink` class should
     * be applied
     */
    shrink?: boolean;
}
export declare const GroupItem: React.ForwardRefExoticComponent<IGroupItemProps & React.RefAttributes<HTMLDivElement>>;
interface IGroupProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Flag to indicate if `input-group-sm` class should
     * be applied
     */
    small?: boolean;
    /**
     * Flag to indicate if `input-group-stacked-sm-down` class
     * should be applied.
     */
    stacked?: boolean;
}
export declare const Group: React.ForwardRefExoticComponent<IGroupProps & React.RefAttributes<HTMLDivElement>>;
export declare const GroupText: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
interface IGroupInsetProps extends React.HTMLAttributes<HTMLDivElement | HTMLSpanElement | HTMLLabelElement> {
    /**
     * Flag to indicate if `input-group-inset-item-after` class
     * should be applied.
     */
    after?: boolean;
    /**
     * Flag to indicate if `input-group-inset-item-before` class
     * should be applied.
     */
    before?: boolean;
    /**
     * Name of container element
     */
    tag?: 'div' | 'span' | 'label';
}
interface IProps extends React.InputHTMLAttributes<HTMLInputElement> {
    /**
     * Input component to render. Can either be a string like 'input' or 'textarea' or a component.
     */
    component?: 'input' | 'textarea' | React.ForwardRefExoticComponent<any>;
    /**
     * Flag to indicate if `input-group-inset-after` class should be applied
     */
    insetAfter?: boolean;
    /**
     * Flag to indicate if `input-group-inset-before` class should be applied
     */
    insetBefore?: boolean;
    /**
     * Selects the height of the input.
     */
    sizing?: 'lg' | 'regular' | 'sm';
}
export declare const Input: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLInputElement>> & {
    Group: React.ForwardRefExoticComponent<IGroupProps & React.RefAttributes<HTMLDivElement>>;
    GroupInsetItem: React.ForwardRefExoticComponent<IGroupInsetProps & React.RefAttributes<HTMLDivElement | HTMLLabelElement | HTMLSpanElement>>;
    GroupItem: React.ForwardRefExoticComponent<IGroupItemProps & React.RefAttributes<HTMLDivElement>>;
    GroupText: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
};
export default Input;
