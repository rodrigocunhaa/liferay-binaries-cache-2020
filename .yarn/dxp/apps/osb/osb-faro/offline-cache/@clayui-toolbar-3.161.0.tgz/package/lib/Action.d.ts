/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
    /**
     * Flag that determines if the Action will have a `disabled` class, disabling interactions.
     */
    disabled?: boolean;
    /**
     * Path to clay icon spritemap
     */
    spritemap?: string;
    /**
     * Symbol of the icon used inside the Action. You can find available symbols here: https://clayui.com/docs/components/icon.html
     */
    symbol: string;
}
export declare function Action({ className, disabled, spritemap, symbol, ...otherProps }: IProps): React.JSX.Element;
export declare namespace Action {
    var displayName: string;
}
