/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export declare type Item = {
    id: string;
    label: string;
    name?: string;
    symbol?: string;
};
declare type Messages = {
    default: string;
    option: string;
    translated: string;
    translating: string;
    trigger: string;
    untranslated: string;
};
declare type Translation = {
    total: number;
    translated: number;
};
declare type Translations = {
    [key: string]: Translation;
};
declare type Props = {
    /**
     * Flag to indicate if the Picker is active or not (controlled).
     */
    active?: boolean;
    /**
     * Class names for the trigger.
     */
    classNamesTrigger?: string;
    /**
     * Property to set the default value of `active` (uncontrolled).
     */
    defaultActive?: boolean;
    /**
     * The default locale id.
     */
    defaultLocaleId?: React.Key;
    /**
     * The initial selected locale id (uncontrolled).
     */
    defaultSelectedLocaleId?: React.Key;
    /**
     * Flag to hide the text in the trigger.
     */
    hideTriggerText?: boolean;
    /**
     * The id of the component.
     */
    id?: string;
    /**
     * List of locales to allow localization for.
     */
    locales: Array<Item>;
    /**
     * Messages for the component.
     */
    messages?: Messages;
    /**
     * Callback for when the active state changes (controlled).
     */
    onActiveChange?: InternalDispatch<boolean>;
    /**
     * Callback that gets called when a selected locale gets changed.
     */
    onSelectedLocaleChange?: InternalDispatch<React.Key>;
    /**
     * Exposes the currently selected locale id (controlled).
     */
    selectedLocaleId?: React.Key;
    /**
     * Flag to make the picker only as wide as its contents.
     */
    shrink?: boolean;
    /**
     * Flag to show the picker in small size.
     */
    small?: boolean;
    /**
     * Path to the location of the spritemap resource.
     */
    spritemap?: string;
    /**
     * Translations provided to the component to display the translation language status.
     */
    translations?: Translations;
};
export declare function LanguagePicker({ active, classNamesTrigger, defaultActive, defaultLocaleId, defaultSelectedLocaleId, hideTriggerText, id, messages, locales, onActiveChange, onSelectedLocaleChange, selectedLocaleId, shrink, small, spritemap, translations, }: Props): React.JSX.Element;
export {};
