/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import type { ICollectionProps } from '@clayui/core';
import type { Item, Locators } from './types';
interface IMenuRendererProps {
    /**
     * Value of input
     * * @deprecated since v3.49.0 - use `value` instead.
     */
    inputValue: string;
    locator: Locators;
    onItemClick?: (item: Item) => void;
    sourceItems: Array<Item>;
    /**
     * The value property sets the current value (controlled).
     */
    value: string;
}
declare type MenuRenderer = (props: IMenuRendererProps) => JSX.Element;
export interface IProps<T extends Record<string, any> = Item> extends Omit<React.HTMLAttributes<HTMLInputElement>, 'onChange' | 'children'>, Omit<Partial<ICollectionProps<T, unknown>>, 'virtualize' | 'items'> {
    /**
     * Flag to indicate if menu is showing or not.
     */
    active?: boolean;
    /**
     * Flag to align the Autocomplete within the viewport.
     * @deprecated since v3.95.2 - it is no longer necessary...
     */
    alignmentByViewport?: boolean;
    /**
     * Whether the selected options may be duplicate items.
     */
    allowDuplicateValues?: boolean;
    /**
     * Whether MultiSelect allows an input value not corresponding to an item
     * to be added.
     */
    allowsCustomLabel?: boolean;
    /**
     * Title for the `Clear All` button.
     */
    clearAllTitle?: string;
    /**
     * Aria label for the Close button of the labels.
     */
    closeButtonAriaLabel?: string;
    /**
     * The initial value of the active state (uncontrolled).
     */
    defaultActive?: boolean;
    /**
     * Set the default value of label items (uncontrolled).
     */
    defaultItems?: Array<T>;
    /**
     * Property to set the default value (uncontrolled).
     */
    defaultValue?: string;
    /**
     * Direction the menu will render relative to the Autocomplete.
     */
    direction?: 'bottom' | 'top';
    /**
     * Flag that indicates to disable all features of the component.
     */
    disabled?: boolean;
    /**
     * Flag to disabled Clear All functionality.
     */
    disabledClearAll?: boolean;
    /**
     * Defines the description of hotkeys for the component, use this
     * to handle internationalization.
     * @deprecated since v3.96.1 - use `messages` instead.
     */
    hotkeysDescription?: string;
    /**
     * Value used for each selected item's hidden input name attribute
     */
    inputName?: string;
    /**
     * Value of input
     * * @deprecated since v3.49.0 - use `value` instead.
     */
    inputValue?: string;
    /**
     * Flag to indicate if loading icon should be rendered
     * @deprecated since v3.95.2 - use `loadingState` instead.
     */
    isLoading?: boolean;
    /**
     * Flag to indicate if input is valid or not
     */
    isValid?: boolean;
    /**
     * Values that display as label items (controlled).
     */
    items?: Array<T>;
    /**
     * The off-screen live region informs screen reader users the result of
     * removing or adding a label.
     * @deprecated since v3.96.1 - use `messages` instead.
     */
    liveRegion?: {
        added: string;
        removed: string;
    };
    /**
     * The current state of Autocomplete current loading. Determines whether the
     * loading indicator should be shown or not.
     */
    loadingState?: number;
    /**
     * Sets the names of the fields to map the value/label of the item
     */
    locator?: Locators;
    /**
     * Adds a component to replace the default component that renders
     * the content of the `<ClayDropDown />` component.
     * @deprecated since v3.95.2
     */
    menuRenderer?: MenuRenderer;
    /**
     * Messages for the Multi Select.
     */
    messages?: {
        hotkeys: string;
        labelAdded: string;
        labelRemoved: string;
        listCount?: string;
        listCountPlural?: string;
        loading: string;
        notFound: string;
    };
    /**
     * Callback for when the active state changes (controlled).
     */
    onActiveChange?: InternalDispatch<boolean>;
    /**
     * Callback for when the input value changes (controlled).
     */
    onChange?: InternalDispatch<string>;
    /**
     * Callback for when the clear all button is clicked
     */
    onClearAllButtonClick?: () => void;
    /**
     * Callback for when items are added or removed (controlled).
     */
    onItemsChange?: InternalDispatch<Array<T>>;
    /**
     * Callback is called when more items need to be loaded when the scroll
     * reaches the bottom.
     */
    onLoadMore?: () => Promise<any> | null;
    /**
     * Placeholder text for autocomplete input
     */
    placeholder?: string;
    /**
     * Determines the size of the Multi Select component.
     */
    size?: null | 'sm';
    /**
     * List of pre-populated items that will show up in a dropdown menu
     */
    sourceItems?: Array<T> | null;
    /**
     * Path to spritemap for clay icons
     */
    spritemap?: string;
    /**
     * The value property sets the current value (controlled).
     */
    value?: string;
}
declare type Component = <T extends Record<string, any> = Item>(props: IProps<T> & React.RefAttributes<HTMLInputElement>) => React.ReactElement | null;
export declare const MultiSelect: Component;
/**
 * Utility used for filtering an array of items based off the locator which
 * is set to `label` by default.
 * @deprecated since v3.95.2 - it is no longer necessary...
 */
/**
 * Utility used for filtering an array of items based off the locator which
 * is set to `label` by default.
 * @deprecated since v3.95.2 - it is no longer necessary...
 */
export declare function itemLabelFilter(items: Array<Item>, _value: string, _locator?: string): Item[];
export {};
