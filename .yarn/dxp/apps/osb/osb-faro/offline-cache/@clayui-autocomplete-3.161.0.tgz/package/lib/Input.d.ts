/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { ClayInput } from '@clayui/form';
import React from 'react';
export interface IProps extends React.InputHTMLAttributes<HTMLInputElement>, React.ComponentProps<typeof ClayInput> {
}
declare const ClayAutocompleteInput: React.ForwardRefExoticComponent<Omit<IProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export default ClayAutocompleteInput;
