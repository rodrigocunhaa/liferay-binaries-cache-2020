/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLUListElement> {
    /**
     * @ignore
     */
    activation?: 'manual' | 'automatic';
    /**
     * @ignore
     */
    active?: React.Key;
    /**
     * The tabs content.
     */
    children: React.ReactNode;
    /**
     * The custom class.
     */
    className?: string;
    /**
     * @ignore
     */
    displayType?: null | 'basic' | 'light' | 'underline';
    /**
     * @ignore
     */
    justified?: boolean;
    /**
     * @ignore
     */
    modern?: boolean;
    /**
     * @ignore
     */
    onActiveChange?: InternalDispatch<number>;
    /**
     * @ignore
     */
    shouldUseActive?: boolean;
    /**
     * @ignore
     */
    tabsId?: string;
}
export declare const List: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLUListElement>>;
