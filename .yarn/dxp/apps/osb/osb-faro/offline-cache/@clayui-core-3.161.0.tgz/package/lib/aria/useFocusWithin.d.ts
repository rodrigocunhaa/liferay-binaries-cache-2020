/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props<T> = {
    children: React.ReactNode;
    containerRef: React.RefObject<T>;
    focusableElements: Array<string>;
};
export declare function FocusWithinProvider<T extends HTMLElement>({ children, containerRef, focusableElements, }: Props<T>): React.JSX.Element;
declare type FocusWithinProps = {
    disabled: boolean;
    id: React.Key;
    onFocusChange?: (isFocused: boolean) => void;
};
export declare function useFocusWithin({ disabled, id, onFocusChange: onFocusChanged, }: FocusWithinProps): {
    tabIndex: number;
    onBlur?: undefined;
    onFocus?: undefined;
} | {
    onBlur: () => void;
    onFocus: <T>(event: React.FocusEvent<T, Element>) => void;
    tabIndex: number;
};
export {};
