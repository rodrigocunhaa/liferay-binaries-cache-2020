/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IBodyProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Props to add to the iframe element
     */
    iFrameProps?: React.HTMLAttributes<HTMLIFrameElement>;
    /**
     * Flag to indicate if body should be a fixed height with a scrollable overflow.
     */
    scrollable?: boolean;
    /**
     * Url to place an iframe in the body of the modal.
     */
    url?: string;
}
declare function Body({ children, className, iFrameProps, scrollable, url, ...otherProps }: IBodyProps): React.JSX.Element;
export default Body;
