/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import DropDown from './DropDown';
import LoadingIndicator from './LoadingIndicator';
import type { IProps as IAutocompleteProps } from './Autocomplete';
export interface IProps<T> extends IAutocompleteProps<T> {
    /**
     * Div component to render. It can be a one component that will replace the markup.
     */
    component?: React.ForwardRefExoticComponent<any>;
}
declare type Component = <T extends Record<string, any> | string | number>(props: IProps<T> & React.RefAttributes<HTMLInputElement>) => React.ReactElement | null;
export declare const ClayAutocomplete: Component;
declare const _default: Component & {
    DropDown: typeof DropDown;
    Input: React.ForwardRefExoticComponent<Omit<import("./Input").IProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
    Item: React.ForwardRefExoticComponent<import("./Item").IProps & React.RefAttributes<HTMLLIElement>>;
    LoadingIndicator: typeof LoadingIndicator;
};
export default _default;
