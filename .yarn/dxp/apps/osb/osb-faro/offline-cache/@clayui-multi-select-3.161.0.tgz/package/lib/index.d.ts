/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
import { itemLabelFilter } from './MultiSelect';
import type { IProps } from './MultiSelect';
export { itemLabelFilter };
export type { IProps };
declare const _default: (<T extends Record<string, any> = import("./types").Item>(props: IProps<T> & import("react").RefAttributes<HTMLInputElement>) => import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>> | null) & {
    Item: import("react").ForwardRefExoticComponent<import("@clayui/autocomplete/lib/Item").IProps & import("react").RefAttributes<HTMLLIElement>>;
};
export default _default;
