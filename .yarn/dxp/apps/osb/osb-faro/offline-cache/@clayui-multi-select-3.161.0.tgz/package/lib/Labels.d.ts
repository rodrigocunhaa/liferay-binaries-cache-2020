/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { ClayInput } from '@clayui/form';
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import type { Item, LastChangeLiveRegion, Locators } from './types';
interface IProps extends React.ComponentProps<typeof ClayInput> {
    allowDuplicateValues?: boolean;
    allowsCustomLabel?: boolean;
    ariaDescriptionId: string;
    closeButtonAriaLabel: string;
    inputName?: string;
    labels: Array<Item>;
    lastChangesRef: React.MutableRefObject<LastChangeLiveRegion | null>;
    locator: Locators;
    onFocusChange: (value: boolean) => void;
    onLabelsChange: InternalDispatch<Array<Item>>;
    spritemap?: string;
    suggestionList: Array<Item>;
}
export declare const Labels: React.ForwardRefExoticComponent<Omit<IProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export {};
