/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
declare type Bounds = {
    height: number;
    width: number;
    x: number;
    y: number;
};
declare type Props<T> = {
    /**
     * Sets the current value of bounds to define the highlight area (controlled).
     */
    bounds?: Bounds;
    /**
     * Sets the element that will receive the highlight.
     */
    children?: React.ReactNode | ((ref: React.RefObject<T>) => React.ReactNode);
    /**
     * Sets the default value of bounds (uncontrolled).
     */
    defaultBounds?: Bounds;
    /**
     * Callback is called when the bounds changes (controlled).
     */
    onBoundsChange?: InternalDispatch<Bounds>;
    /**
     * Callback is called when the overlay is clicked.
     */
    onClick?: (event: React.MouseEvent<SVGRectElement>) => void;
    /**
     * Set the highlight padding.
     */
    padding?: number;
    /**
     * Sets the current visibility of the overlay.
     */
    visible?: boolean;
};
export declare function OverlayMask<T extends HTMLElement>({ defaultBounds, bounds, children, onClick, onBoundsChange, padding, visible, }: Props<T>): React.JSX.Element;
export {};
