/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLLIElement> {
    /**
     * Flag to indicate if Item should auto expand to fill the remaining width.
     */
    expand?: boolean;
}
export declare function Item({ children, className, expand, ...otherProps }: IProps): React.JSX.Element;
export declare namespace Item {
    var displayName: string;
}
