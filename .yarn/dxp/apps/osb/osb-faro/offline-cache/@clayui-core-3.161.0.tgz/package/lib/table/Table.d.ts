/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import { Sorting } from './context';
interface IProps extends React.HTMLAttributes<HTMLTableElement> {
    /**
     * Defines the columns that are always visible and will be ignored by the
     * visible columns functionality.
     */
    alwaysVisibleColumns?: Set<React.Key>;
    /**
     * This property vertically align the contents
     * inside the table body according a given position.
     */
    bodyVerticalAlignment?: 'bottom' | 'middle' | 'top';
    /**
     * Applies a Bordered style on Table's columns.
     */
    borderedColumns?: boolean;
    /**
     * Removes the default border and rounded corners from table.
     */
    borderless?: boolean;
    /**
     * Flag to enable column visibility control.
     */
    columnsVisibility?: boolean;
    /**
     * Property to set the initial value of `expandedKeys` (uncontrolled).
     */
    defaultExpandedKeys?: Set<React.Key>;
    /**
     * Default state of sort (uncontrolled).
     */
    defaultSort?: Sorting | null;
    /**
     * Default value for visible columns in the table (uncontrolled).
     */
    defaultVisibleColumns?: Map<React.Key, number>;
    /**
     * The currently expanded keys in the collection (controlled).
     */
    expandedKeys?: Set<React.Key>;
    /**
     * This property vertically align the contents
     * inside the table header according a given position.
     */
    headVerticalAlignment?: 'bottom' | 'middle' | 'top';
    /**
     * This property keeps all the headings on one line.
     */
    headingNoWrap?: boolean;
    /**
     * Applies a Hover style on Table.
     */
    hover?: boolean;
    /**
     * Defines which key should be used as the item identifier.
     */
    itemIdKey?: string;
    /**
     * Messages for the Table.
     */
    messages?: {
        columnsVisibility: string;
        columnsVisibilityCell?: string;
        columnsVisibilityDescription: string;
        columnsVisibilityHeader: string;
        expandable: string;
        sortDescription: string;
        sorting: string;
    };
    /**
     * Flag to indicate which key name matches the nested rendering of the tree.
     */
    nestedKey?: string;
    /**
     * This property enables keeping everything on one line.
     */
    noWrap?: boolean;
    /**
     * A callback that is called when items are expanded or collapsed
     * (controlled).
     */
    onExpandedChange?: (keys: Set<React.Key>) => void;
    /**
     * When a tree is very large, loading items (nodes) asynchronously is preferred to
     * decrease the initial payload and memory space. The callback is called every time
     * the item is a leaf node of the tree.
     */
    onLoadMore?: (item: unknown) => Promise<Array<any> | undefined>;
    /**
     * Callback for when the sorting change (controlled).
     */
    onSortChange?: (sorting: Sorting | null) => void;
    /**
     * Callback called when columns visibility changes (controlled).
     */
    onVisibleColumnsChange?: (columns: Map<React.Key, number>) => void;
    /**
     * Turns the table responsive.
     */
    responsive?: boolean;
    /**
     * Defines the responsive sizing.
     */
    responsiveSize?: 'lg' | 'md' | 'sm' | 'xl';
    /**
     * Defines the size of the table.
     */
    size?: 'sm' | 'lg';
    /**
     * Current state of sort (controlled).
     */
    sort?: Sorting | null;
    /**
     * Applies a Striped style on Table.
     */
    striped?: boolean;
    /**
     * This property vertically align the contents
     * inside the table according a given position.
     */
    tableVerticalAlignment?: 'bottom' | 'middle' | 'top';
    /**
     * Defines which columns are visible in the table (controlled).
     */
    visibleColumns?: Map<React.Key, number>;
}
export declare const Table: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLTableElement>>;
export {};
