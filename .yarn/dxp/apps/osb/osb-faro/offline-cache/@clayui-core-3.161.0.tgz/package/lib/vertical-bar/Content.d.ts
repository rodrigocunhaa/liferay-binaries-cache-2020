/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { ICollectionProps } from '../collection';
declare type Context = {
    displayType?: 'light' | 'dark';
};
export declare const ContentContext: React.Context<Context>;
interface IProps<T> extends Omit<ICollectionProps<T, unknown>, 'virtualize'> {
    /**
     * Flag to determine which style the VerticalBar will display.
     */
    displayType?: 'light' | 'dark';
}
export declare function Content<T>({ children, displayType, items, }: IProps<T>): React.JSX.Element;
export {};
