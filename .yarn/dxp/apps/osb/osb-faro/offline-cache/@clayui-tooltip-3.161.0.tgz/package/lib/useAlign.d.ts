/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare const ALIGNMENTS: readonly ["top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left"];
export declare type Align = (typeof ALIGNMENTS)[number];
declare type Props = {
    align: Align;
    autoAlign: boolean;
    floating: boolean;
    isOpen: boolean;
    onAlign: (align: Align) => void;
    sourceElement: React.MutableRefObject<HTMLElement | null>;
    targetElement: React.MutableRefObject<HTMLElement | null>;
    title: string;
};
export declare function useAlign({ align, autoAlign, floating, isOpen, onAlign, sourceElement, targetElement, title, }: Props): void;
export {};
