/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
    /**
     * Adds `.container-fluid` class to create a fluid container that
     * doesn't expand beyond a set width
     */
    fluid?: boolean;
    /**
     * Adds `.container-fluid-${size}` class to set max width on container.
     */
    fluidSize?: 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | 'xxxl';
    /**
     * Adds the `.container-form-${formSize}` class to properly space
     * between application controls and the form. This class only modifies
     * the padding on the container.
     */
    formSize?: 'sm' | 'md' | 'lg' | 'xl';
    /**
     * Adds the `.container-view` class to properly space between application
     * controls and view pages (e.g., Card View, Table View, or List View).
     * This class only modifies the padding on the container.
     */
    view?: boolean;
}
declare const Container: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLElement>>;
export default Container;
