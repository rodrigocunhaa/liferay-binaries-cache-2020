/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare type AnnouncerAPI = {
    announce: (message: string, assertiveness?: 'assertive' | 'polite') => void;
};
/**
 * TODO: LiveAnnouncer should be a singleton.
 */
export declare const LiveAnnouncer: React.ForwardRefExoticComponent<React.RefAttributes<AnnouncerAPI>>;
