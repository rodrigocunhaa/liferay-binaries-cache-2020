/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export declare type Props = {
    /**
     * Flag to indicate if menu is showing or not (controlled).
     */
    active?: boolean;
    /**
     * The initial value of the active state (uncontrolled).
     */
    defaultActive?: boolean;
    /**
     * The initial value of the icon state (uncontrolled).
     */
    defaultSelectedIcon?: string;
    /**
     * Direction the menu will render relative to the trigger.
     */
    direction?: 'bottom' | 'top';
    /**
     * Messages for the Icon Selector.
     */
    messages?: {
        changeIconButton: string;
        clearInput?: string;
        iconSelected: string;
        notFound: string;
        placeholder?: string;
        removeIcon: string;
        selectIcon: string;
        selectIconButton?: string;
    };
    /**
     * Callback for when the active state changes (controlled).
     */
    onActiveChange?: InternalDispatch<boolean>;
    /**
     * Callback when an icon is selected.
     */
    onIconChange?: InternalDispatch<string>;
    /**
     * Selected icon (controlled).
     */
    selectedIcon?: string;
    /**
     * URL of the SVG icons.
     */
    spritemap: string;
};
export declare function IconSelector({ active: externalActive, defaultActive, defaultSelectedIcon, direction, messages, selectedIcon: externalSelectedIcon, onIconChange, onActiveChange, spritemap, }: Props): React.JSX.Element;
