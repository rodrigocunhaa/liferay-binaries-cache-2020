/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
import type { CollectionState, ICollectionProps, Props } from './types';
declare type ItemLoc = {
    nextKey?: React.Key;
    prevKey?: React.Key;
};
export declare function useCollection<T extends Record<string, any> | string | number, P = unknown, K = unknown>({ children, connectNested, exclude, filter, filterKey, forceDeepRootUpdate, itemContainer: ItemContainer, itemIdKey, items, notFound, parentKey, passthroughKey, publicApi, suppressTextValueWarning, virtualizer, visibleKeys, }: ICollectionProps<T, P> & Props<P, K>): CollectionState;
export declare function useCollectionKeys(): React.MutableRefObject<Map<React.Key, ItemLoc>>;
export {};
