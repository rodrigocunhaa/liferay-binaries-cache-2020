/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare type Level = 1 | 2 | 3 | 4 | 5 | 6;
export declare type WeightFont = 'lighter' | 'light' | 'normal' | 'semi-bold' | 'bold' | 'bolder';
declare type Props = {
    /**
     * Heading content.
     */
    children?: React.ReactNode;
    /**
     * Determines the font size of the heading regardless of the tag.
     */
    fontSize?: Level;
    /**
     * Number to set the heading level.
     */
    level?: Level;
    /**
     * Determines the weight of the font.
     */
    weight?: WeightFont;
};
export declare function Heading({ children, fontSize, level, weight, }: Props): React.JSX.Element;
export declare namespace Heading {
    var displayName: string;
}
export {};
