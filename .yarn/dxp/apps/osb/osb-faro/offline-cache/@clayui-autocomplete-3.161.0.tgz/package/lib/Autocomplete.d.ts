/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { ClayInput as Input } from '@clayui/form';
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import type { ICollectionProps } from '@clayui/core';
import type { Locator } from '@clayui/shared';
export declare type AutocompleteMessages = {
    infiniteScrollInitialLoad?: string;
    infiniteScrollInitialLoadPlural?: string;
    infiniteScrollOnLoad?: string;
    infiniteScrollOnLoaded?: string;
    infiniteScrollOnLoadedPlural?: string;
    listCount?: string;
    listCountPlural?: string;
    loading: string;
    notFound: string;
};
export interface IProps<T> extends Omit<React.HTMLAttributes<HTMLInputElement>, 'onChange' | 'children'>, Omit<Partial<ICollectionProps<T, unknown>>, 'virtualize' | 'items'> {
    /**
     * Internal property to change the loading indicator markup to shrink.
     * @ignore
     */
    UNSAFE_loadingShrink?: boolean;
    /**
     * Flag to indicate if menu is showing or not.
     */
    active?: boolean;
    /**
     * Flag to align the DropDown menu within the viewport.
     * @deprecated since v3.92.0 - it is no longer necessary..
     */
    alignmentByViewport?: boolean;
    /**
     * Flag to allow an input value not corresponding to an item to be set.
     */
    allowsCustomValue?: boolean;
    /**
     * Custom input component.
     */
    as?: 'input' | React.ForwardRefExoticComponent<any> | ((props: React.ComponentProps<typeof Input>) => JSX.Element);
    /**
     * The initial value of the active state (uncontrolled).
     */
    defaultActive?: boolean;
    /**
     * Property to set the initial value of `items` (uncontrolled).
     */
    defaultItems?: Array<T> | null;
    /**
     * The initial value of the input (uncontrolled).
     */
    defaultValue?: string;
    /**
     * Direction the menu will render relative to the Autocomplete.
     */
    direction?: 'bottom' | 'top';
    /**
     * The estimated height of an item that is used by the virtualizer.
     */
    estimateSize?: number;
    /**
     * Defines the name of the property key that is used in the items filter
     * test (Dynamic content).
     */
    filterKey?: Locator;
    /**
     * Property to render content with dynamic data.
     */
    items?: Array<T> | null;
    /**
     * The current state of Autocomplete current loading. Determines whether the
     * loading indicator should be shown or not.
     */
    loadingState?: number;
    /**
     * The interaction required to display the menu.
     */
    menuTrigger?: 'input' | 'focus';
    /**
     * Messages for the Autocomplete.
     */
    messages?: AutocompleteMessages;
    /**
     * Callback for when the active state changes (controlled).
     */
    onActiveChange?: InternalDispatch<boolean>;
    /**
     * Callback called when input value changes (controlled).
     */
    onChange?: InternalDispatch<string>;
    /**
     * Callback called when items change (controlled).
     */
    onItemsChange?: InternalDispatch<Array<T> | null>;
    /**
     * Callback is called when more items need to be loaded when the scroll
     * reaches the bottom.
     */
    onLoadMore?: () => Promise<any> | null;
    /**
     * Config for showing a default action as the first item in the dropdown
     */
    primaryAction?: {
        label: React.ReactNode;
        onClick: () => void;
    };
    /**
     * The currently selected keys (controlled).
     */
    selectedKeys?: Array<React.Key>;
    /**
     * The current value of the input (controlled).
     */
    value?: string;
    [key: string]: any;
}
declare type ForwardRef = {
    <T>(props: IProps<T> & {
        ref?: React.Ref<HTMLInputElement>;
    }): JSX.Element;
    displayName: string;
};
export declare const Autocomplete: ForwardRef;
export {};
