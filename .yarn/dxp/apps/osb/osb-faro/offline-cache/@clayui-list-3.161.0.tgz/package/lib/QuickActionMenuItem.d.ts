/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IItemProps extends React.HTMLAttributes<HTMLAnchorElement | HTMLButtonElement> {
    /**
     * Value of path the item should link to.
     */
    href?: string;
    /**
     * Path to icon spritemap.
     */
    spritemap?: string;
    /**
     * Name of icon symbol
     */
    symbol: string;
}
declare const QuickActionMenuItem: React.ForwardRefExoticComponent<IItemProps & React.RefAttributes<HTMLAnchorElement & HTMLButtonElement>>;
export default QuickActionMenuItem;
