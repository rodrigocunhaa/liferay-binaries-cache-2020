/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Element or component to render for container
     */
    containerElement?: string | React.JSXElementConstructor<{
        className: string;
        [key: string]: any;
    }>;
    /**
     * This removes the negative margins from .row and the
     * horizontal padding from all immediate children columns
     */
    gutters?: boolean;
    /**
     * Horizontal positioning of row contents
     */
    justify?: 'start' | 'center' | 'end' | 'around' | 'between';
}
declare const Row: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLElement>>;
export default Row;
