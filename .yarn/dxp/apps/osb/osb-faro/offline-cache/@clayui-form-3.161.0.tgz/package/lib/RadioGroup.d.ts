/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
import Radio from './Radio';
import Toggle from './Toggle';
interface IGroupProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    /**
     * Takes either Radio or Toggle as a child.
     */
    children: Array<React.ReactElement<React.ComponentProps<typeof Radio>> | React.ReactElement<React.ComponentProps<typeof Toggle>>>;
    /**
     * Property to set the default value (uncontrolled).
     */
    defaultValue?: React.ReactText;
    /**
     * Flag to indicate if radio elements should display inline.
     */
    inline?: boolean;
    /**
     * Form element `name` that is applied to each radio element.
     */
    name?: string;
    /**
     * Callback function for whenever a radio element is selected (controlled).
     */
    onChange?: InternalDispatch<React.ReactText>;
    /**
     * Callback function for whenever a radio element is selected.
     * @deprecated since v3.51.0 - use `onChange` instead.
     */
    onSelectedValueChange?: InternalDispatch<React.ReactText>;
    /**
     * The value that corresponds to the selected radio element. Leave
     * undefined if no option is selected.
     * @deprecated since v3.51.0 - use `value` instead.
     */
    selectedValue?: React.ReactText;
    /**
     * The value property sets the current value (controlled).
     */
    value?: React.ReactText;
}
declare function RadioGroup({ children, className, defaultValue, inline, name, onChange, onSelectedValueChange, selectedValue, value, ...otherProps }: IGroupProps): React.JSX.Element;
export default RadioGroup;
