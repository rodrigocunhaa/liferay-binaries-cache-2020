/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
declare type Props = {
    delay?: number;
};
export declare function useTooltipState({ delay }: Props): {
    close: () => void;
    isOpen: boolean;
    open: (immediate: boolean, customDelay?: number) => void;
};
export {};
