/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
export declare type Status = 'danger' | 'info' | 'success' | 'warning';
export declare type Size = 'full-screen' | 'lg' | 'sm';
export declare enum ObserverType {
    Close = 0,
    Open = 1,
    RestoreFocus = 2
}
export declare type Observer = {
    dispatch: (type: ObserverType, payload?: any) => void;
    mutation: [boolean, boolean];
};
