/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IProps extends React.InputHTMLAttributes<HTMLInputElement> {
    /**
     * Flag to indicate if input is checked or not.
     */
    checked: boolean;
    /**
     * Props to add to the outer most container.
     */
    containerProps?: React.HTMLAttributes<HTMLDivElement>;
    /**
     * Props to disable checkbox.
     */
    disabled?: boolean;
    /**
     * Flag to indicate that checkbox is in an indeterminate state.
     */
    indeterminate?: boolean;
    /**
     * Flag to display element `inline`.
     */
    inline?: boolean;
    /**
     * Text describes what the checkbox is for.
     */
    label?: React.ReactText;
    /**
     * Callback for when checkbox value is changed.
     */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
declare const Checkbox: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLInputElement>>;
export default Checkbox;
